package com.used.chat;

import java.security.Principal;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.web.socket.messaging.SessionConnectEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

/*
 Controller에서 client의 connect/disconnect 여부를 알기 어려움
 EventListener 어노테이션으로 세션이 연결되거나 해제되는 이벤트를 감지함
 */
public class StompEventListener {
	private RoomListRepository roomList;
	
	private SimpMessagingTemplate messagingTemplate;
	
	public StompEventListener(SimpMessagingTemplate messagingTemplate, RoomListRepository roomList) {
		// TODO Auto-generated constructor stub
		this.messagingTemplate = messagingTemplate;
		this.roomList = roomList;
	}
	
	@EventListener
	private void handleSessionConnected(SessionConnectEvent event) { // stomp client.connect 후 여기로 옴 
		boolean isadmin = false;
		SimpMessageHeaderAccessor headers = SimpMessageHeaderAccessor.wrap(event.getMessage());  // 많은 정보가 담겨 있음 잘 모름
	
		String username = headers.getUser().getName(); // principal.getName()임 로그인한 아이디 가져옴
		
		Map<String,Object> attr = headers.getSessionAttributes(); // http session의 Attribute를 다 가져오는 거 같음
		 SecurityContext securityContext = (SecurityContext) attr.get("SPRING_SECURITY_CONTEXT"); // 시큐리티 컨텍스트 가져옴
		 Authentication auth = securityContext.getAuthentication(); // 여기부터 아래 while까지 로그인 사용자 권한 가져옴
		 Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();
		 Iterator<? extends GrantedAuthority> iter = authorities.iterator(); 
		 while(iter.hasNext()) { 
			GrantedAuthority auth1 = iter.next();
		  	if(auth1.getAuthority().equals("ROLE_ADMIN")) isadmin=true; // 관리자면 방리스트 생성 안 함 -> 관리자가 방을 생성할 이유가 없음
		 }
		 
		String sessionid = headers.getSessionId(); // uuid값
		Map<String,String> list = roomList.getRoomlist(); // repository에 들어갈 맵
		if(!list.containsKey(username)&&!isadmin) list.put(username,sessionid); // list에 생성한 방이 있는지 체크하고 넣음
	}
	
	@EventListener
	private void handleSessionDisconnect(SessionDisconnectEvent event) { // 방 생성할 때 key에 연결된 client의 session이 끊기면 리스트에서 삭제함 chat에서 room session id랑 client session id 비교하는 이유임 

		SimpMessageHeaderAccessor headers = SimpMessageHeaderAccessor.wrap(event.getMessage());
		String username = headers.getUser().getName();
		Map<String,String> list = roomList.getRoomlist();
		String sessionid = headers.getSessionId();
		if(list.containsKey(username)&&list.get(username).equals(sessionid)) list.remove(username);
		
	}
}
