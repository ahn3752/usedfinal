package com.used.chat;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ChatImpl {
	public List<String> getRoomList(String user);
	public List<ChatRoomlist> getRoomList2(String user);
	public int checkList(String roomid);
	public void createRoom(String roomid,String user,String user2);
	public List<ChatMessage> getlog(String roomid);
	public void chat(String roomid,String user,String message);
	
}
