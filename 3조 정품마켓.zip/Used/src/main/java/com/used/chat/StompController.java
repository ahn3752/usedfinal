package com.used.chat;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class StompController{
	//private List<String> roomlist = new ArrayList<String>();
	
	@Autowired private RoomListRepository roomList; // 방목록 저장용
	@Autowired ChatService chatService;
	private SimpMessagingTemplate template; // 메세지 전송 템플릿

	@Autowired
	public StompController(SimpMessagingTemplate template) {
		// TODO Auto-generated constructor stub
		this.template = template;
		
	}

	
	@MessageMapping("/chat/list") // client에서 /chat/list 로 send했을 때 
	public void list() {
		
		List<String> list = new ArrayList<String>();
		for(String roomname : roomList.getRoomlist().keySet()) { //모든 키값(roomid) 리스트화
			list.add(roomname);
		}
		template.convertAndSend("/room/", list); // /room/(관리자페이지에서만 사용)에 subscribe된 모든 stomp client에 list 전송 
		
	}
	
    @MessageMapping("/chat/message/{type}") // client에서 chat/message/{type}으로 send
    public void message(ChatMessage message, @DestinationVariable String type,SimpMessageHeaderAccessor  headerAccessor) {
    	
    	message.setType(type); // 메세지 타입 (join,exit,message) 구분

		message.setRoomSessionId(roomList.getRoomlist().get(message.getWriter())); // 방에 연결된 session id(채팅방 중복생성 방지)
    	message.setSessionId(headerAccessor.getSessionId()); // 현재 stomp client의 session id (랜덤으로 생성됨)
    	if(type.equals("join")) {
    		if(!message.getChatRoomId().equals(message.getWriter())) // 관리자가 접속하면 보낼 메세지 (사용예정)
    		message.setMessage(message.getWriter() + "님이 입장하셨습니다.");
    		
    	}
    	if(type.equals("exit")) {
    		message.setMessage(message.getWriter() + "님이 퇴장하셨습니다."); // 퇴장메세지 (사용예정)
    	}
    	template.convertAndSend("/room/" + message.getChatRoomId(), message); // /room/+채팅방아이디로 subscribe된 모든 stomp client에 메세지 전달
    	
    }
    @MessageMapping("/userchat/join")
    public void join(ChatMessage message,SimpMessageHeaderAccessor  headerAccessor) {
    	List<ChatMessage> chatlog = chatService.getlog(message.getChatRoomId());
    	Collections.sort(chatlog, new Comparator<ChatMessage>() {
    		@Override
	    	public int compare(ChatMessage b1, ChatMessage b2) { 
	    		return b1.getTime().compareTo(b2.getTime()); 
	    	}
    	});


    	for(ChatMessage log : chatlog) {
    		message = log;
        	message.setType("join"); 
        	message.setSessionId(headerAccessor.getSessionId()); 
    	}

    	template.convertAndSend("/room/" + message.getChatRoomId(), chatlog); 
    }
    @MessageMapping("/userchat/message") 
    public void chat(ChatMessage message,SimpMessageHeaderAccessor  headerAccessor) {
    	chatService.chat(message.getChatRoomId(),message.getWriter(),message.getMessage());
    	message.setType("message");
    	template.convertAndSend("/room/" + message.getChatRoomId(), message); 
    }
    
    @MessageMapping("/userchat/list") 
    public void list(ChatMessage message,SimpMessageHeaderAccessor  headerAccessor) {
    	List<ChatRoomlist> list = chatService.getloomlist(message.getWriter());
    	template.convertAndSend("/room/" + message.getWriter(), list); 
    }
}
