package com.used.chat;

import java.util.HashMap;
import java.util.Map;

public class RoomListRepository {
	/*
	 같은 세션(브라우저)이라도 new SockJS로 소켓을 생성(chat.jsp line:55)하면 session id가 UUID(default)로 랜덤 지정됨 -> 고정으로 변경 가능하지만 고치기 매우 귀찮아짐
	 따라서 같은 세션에서 중복 입장을 막기 위해 채팅방 생성시 socket의 세션아이디를 함께 묶어서 저장해 둠 -> 자세한 이유는 StompEventListener.java 확인
	 */
	private Map<String,String> roomlist = new HashMap<String,String>(); // 방목록 맵<채팅방 생성 아이디,채팅방 생성시 세션아이디>
	
	
	public Map<String,String> getRoomlist() {
		return roomlist;
	}
	public void setRoomlist(Map<String,String> roomlist) {
		this.roomlist = roomlist;
	}
}
