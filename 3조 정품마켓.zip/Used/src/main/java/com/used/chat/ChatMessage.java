package com.used.chat;

import java.util.Date;

public class ChatMessage {
    private String chatRoomId; // 방아이디
    private String writer; // 보낸사람
    private String message; // 메세지
    private String type; // 메세지타입 
    private String sessionId; // stomp client 세션아이디
    private String roomSessionId; // 방 세션아이디 >> roomlistRepository 확인
    private Date time;
    private String time2;
    public String getTime2() {
		return time2;
	}
	public void setTime2(String time2) {
		this.time2 = time2;
	}
	public Date getTime() {
		return time;
	}
    public void setTime(Date time) {
		this.time = time;
	}
    public String getType() {
		return type;
	}
    public void setType(String type) {
		this.type = type;
	}
	public String getChatRoomId() {
		return chatRoomId;
	}
	public void setChatRoomId(String chatRoomId) {
		this.chatRoomId = chatRoomId;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getRoomSessionId() {
		return roomSessionId;
	}
	public void setRoomSessionId(String roomSessionId) {
		this.roomSessionId = roomSessionId;
	}
}