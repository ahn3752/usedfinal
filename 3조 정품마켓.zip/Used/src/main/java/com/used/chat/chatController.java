package com.used.chat;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class chatController {
	// 채팅방 입장
	@Autowired
	SqlSession session;
	@Autowired
	ChatService chatService;
	
	@RequestMapping("chat.do") //채팅방 페이지 이동 서블릿
	public String view_chat(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		return "chat";	
	}
	
	@RequestMapping("adminChat.do") // 관리자 페이지 채팅 리스트 출력 서블릿
	public String achat(Model model, HttpServletRequest req) {
		return "achat";
	}
	@RequestMapping("userchat.do")
	public String userchat(HttpServletRequest req, Principal principal) {
		
		String user1 = principal.getName();
		String user2 = req.getParameter("sellerid");
		String roomid = chatService.check(user1, user2);
		
		if(roomid=="방있음") {
			return "test1";
		}
		else if(roomid=="방없음"){
			roomid=chatService.createroom(user1, user2);
		}
		HttpSession session = req.getSession();
		session.setAttribute("roomid", roomid);
		return "userchat";
	}
	@RequestMapping("userchatroom.do")
	public String tes1(Model model, HttpServletRequest req) {
		String roomid = req.getParameter("room");
		HttpSession session = req.getSession();
		session.setAttribute("roomid", roomid);
		return "userchat";
	}
	@RequestMapping("userchatroomlist.do")
	public String test2(Model model, HttpServletRequest req) {
		
		return "userchatroomlist";
	}
	@RequestMapping("home.do")
	public String home(Model model, HttpServletRequest req) {
		
		return "home";
	}
}
