package com.used.chat;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;

import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.server.HandshakeInterceptor;
import org.springframework.web.socket.server.support.HttpSessionHandshakeInterceptor;

@Configuration
@EnableWebSocketMessageBroker
/*
 configuration 하는 방법이 context.xml에 처박던가 여기에 처박던가 하는 방법이 있음
 */
public class WebSocketConfig extends AbstractWebSocketMessageBrokerConfigurer { 
	@Bean // autowire를 위한 빈 *** 이거 때문에 개씹고생함 그냥 15시간은 자료만 쳐다보게 된 씹새기 중에 하나 *** 자세한 건 java파일 확인
	public StompEventListener presenceEventListener(SimpMessagingTemplate messagingTemplate) {
		StompEventListener presence = new StompEventListener(messagingTemplate, participantRepository());
		return presence;  
	}
	@Bean // autowire를 위한 빈
	public RoomListRepository participantRepository() {
		return new RoomListRepository(); 
	}
	@Bean
	public HandshakeInterceptor HttpSessionHandshakeInterceptor() {
		return new HttpSessionHandshakeInterceptor(); // http 세션 가져오는건데 제대로 쓰는건지 모르겠음
	}
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/room"); // 브로커 subcribe와 관련 있음
        registry.setApplicationDestinationPrefixes("/app"); // 잘모름 뭐 보내는 대상(1:1, 1:n)과 관련
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry stompEndpointRegistry) {
        stompEndpointRegistry.addEndpoint("/chat").setAllowedOrigins("*").withSockJS().setInterceptors(HttpSessionHandshakeInterceptor()); // 잘모름 sockjs의 /used/chat과 관련된 것
    }
}
