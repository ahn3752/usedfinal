package com.used.chat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChatServiceImpl implements ChatService{
	@Autowired
	SqlSession session;
	@Override
	public String check(String user1, String user2) {
		// TODO Auto-generated method stub
		Set<String> list = new HashSet<String>();
		List<String> user1List = session.getMapper(ChatImpl.class).getRoomList(user1);
		List<String> user2List = session.getMapper(ChatImpl.class).getRoomList(user2);
		list.addAll(user1List);
		list.addAll(user2List);
		for(String roomid : user1List) {
			if(user2List.contains(roomid)) return roomid;
		}
//		if(user1List.size()!=0&&user2List.size()!=0) {
//			if(user1List.size()+user2List.size()!=list.size()) return "방있음";
//		}
		return "방없음";
	}
	@Override
	public String createroom(String user1, String user2) {
		// TODO Auto-generated method stub
		String roomid = UUID.randomUUID().toString();
		try{
			session.getMapper(ChatImpl.class).createRoom(roomid,user1,user2);
			return roomid;
		}catch(Exception e) {
			e.printStackTrace();
			return "안들어감";
		}
	}
	@Override
	public List<ChatMessage> getlog(String roomid) {
		// TODO Auto-generated method stub
		List<ChatMessage> log = session.getMapper(ChatImpl.class).getlog(roomid);
		return log;
	}@Override
	public void chat(String roomid, String userid, String message) {
		// TODO Auto-generated method stub
		try{
		session.getMapper(ChatImpl.class).chat(roomid,userid,message);
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("채팅 안들어감");
		}
	}
	@Override
	public List<ChatRoomlist> getloomlist(String user) {
		// TODO Auto-generated method stub
		List<ChatRoomlist> list = session.getMapper(ChatImpl.class).getRoomList2(user);
		return list;
	}
}
