package com.used.chat;

import java.util.List;

public interface ChatService {
	public String check(String user1, String user2);
	public List<ChatRoomlist> getloomlist(String user);
	public String createroom(String user1, String user2);
	public List<ChatMessage> getlog(String roomid);
	public void chat(String roomid, String userid, String message);
}
