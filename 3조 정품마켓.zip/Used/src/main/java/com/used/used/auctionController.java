package com.used.used;


import java.io.File;
import java.io.IOException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import oracle.net.aso.s;
import used.auctionDTO;
import used.auctionImpl;
import used.bidDTO;
import used.mainImpl;
import used.payDTO;
import used.successbidDTO;
import util.Coolsms;

@Component
@Controller
public class auctionController {

	@Autowired
	private SqlSession sqlSession;

	auctionDTO auctiondto = new auctionDTO();
	bidDTO biddto = new bidDTO();
	successbidDTO successbiddto = new successbidDTO();
	payDTO paydto = new payDTO();
	
	
	@RequestMapping("auctionlist.do")
	public String auctionlist(Model model) {

		ArrayList<auctionDTO> auctionlist = sqlSession.getMapper(auctionImpl.class).auctionlist(auctiondto);

		model.addAttribute("auctionlist", auctionlist);

		return "auctionlist";
	}
	@RequestMapping("mauctionList.do")
	public String mauctionList(Model model, HttpServletRequest req) {
		String lcategory = req.getParameter("lcategory");
		String mcategory = req.getParameter("mcategory");
		
		ArrayList<auctionDTO> mauctionlist = sqlSession.getMapper(auctionImpl.class).mauctionlist(lcategory,mcategory);

		model.addAttribute("auctionlist", mauctionlist);
		System.out.println(mauctionlist);
		return "auctionlist";
	}
	

	@RequestMapping("auctionView.do")
	public String auctionview(Model model, @RequestParam("aidx") String aidx) {

		auctiondto.setAidx(aidx);
		biddto.setAidx(aidx);

		auctionDTO auctionView = sqlSession.getMapper(auctionImpl.class).auctionview(auctiondto);

		String maxbid = sqlSession.getMapper(auctionImpl.class).maxbid(aidx);

		int bidcount = sqlSession.getMapper(auctionImpl.class).bidcount(biddto);

		if (maxbid == null) {
			maxbid = "0";
		}
		auctiondto.setBprice(maxbid);

		sqlSession.getMapper(auctionImpl.class).updatebprice(auctiondto);

		auctiondto.setBidcount(bidcount);

		sqlSession.getMapper(auctionImpl.class).bidcountupdate(auctiondto);
		model.addAttribute("bidcount", bidcount);
		model.addAttribute("dto", auctionView);
		if (maxbid == "0") {
			
			model.addAttribute("maxbid", 0);
		} else {
			model.addAttribute("maxbid", maxbid);
		}
		return "auctionView";
	}

	@RequestMapping("bid.do")
	public String bid(@RequestParam("bprice") String bprice, @RequestParam("aidx") String aidx,
			HttpServletRequest req) {

		System.out.println(aidx);
		HttpSession session = req.getSession();
		String mid = (String) session.getAttribute("sec_id");

		biddto.setAidx(aidx);
		biddto.setMid(mid);
		biddto.setBprice(bprice);
		sqlSession.getMapper(auctionImpl.class).bid(biddto);

		return "redirect:auctionView.do?aidx=" + aidx;
	}

	@RequestMapping("bidlist.do")
	public String bidlist(Model model, @RequestParam("aidx") String aidx) {

	
		biddto.setAidx(aidx);

		ArrayList<bidDTO> bidlist = sqlSession.getMapper(auctionImpl.class).bidlist(biddto);

		model.addAttribute("bidlist", bidlist);

		return "bidModal";
	}

	@RequestMapping("endAuction.do")
	public String endAuction(auctionDTO auctiondto,@RequestParam(value="aidx", required=false) String aidx) {
		
		
		String status = "낙찰중";
		auctiondto.setStatus(status);
		auctiondto.setAidx(aidx);
		/* successbiddto.setAidx(aidx); */
		
		String bidx = sqlSession.getMapper(auctionImpl.class).maxbidx(aidx);
		
		biddto.setBidx(bidx);
		biddto.setBstatus("낙찰대기중");
		
		
		sqlSession.getMapper(auctionImpl.class).updateStatus(auctiondto);
		sqlSession.getMapper(auctionImpl.class).updateStatusbid(biddto);
		sqlSession.getMapper(auctionImpl.class).updateStatussuccess(biddto);
		/*
		 * sqlSession.getMapper(auctionImpl.class).insertSuccessBidder(successbiddto);
		 */
		
		return "redirect:auctionView.do?aidx="+aidx;
	}
	
	public void test(String phone) throws Exception{
		
		 String api_key = "NCS3DV0FYNXOJIM9";
		    String api_secret = "4N49OEU9M5ONQMUY8RE9Z86DG2BQEAA6";
		    Coolsms coolsms = new Coolsms(api_key, api_secret);

		    HashMap<String, String> set = new HashMap<String, String>();
		    set.put("to", phone); // 수신번호
		    System.out.println("------------");
		    System.out.println(phone);

		    set.put("from", "01048803752"); // 발신번호
		    set.put("text", "<주>정품마켓 입찰하신 물품이 낙찰되셨습니다. 판매자가 낙찰 수락할 경우 구입가능합니다."); // 문자내용
		    set.put("type", "sms"); // 문자 타입

		    System.out.println(set);
		    
		    JSONObject result = coolsms.send(set); // 보내기&전송결과받기
	}
	
	@Scheduled(cron = "0/1 * * * * *") //1초 마다 호출
	public void autoUpdate() throws Exception{
			
		// 날짜시간에 대한 포맷 지정
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
				// 현재 시간을 위의 포맷으로 변경
				String nowTime = LocalTime.now().format(formatter);
				ArrayList<String> selectTime = sqlSession.getMapper(auctionImpl.class).selectTime();

				for(String aidx : selectTime) {
					String sms = sqlSession.getMapper(auctionImpl.class).selectmessagestatus(aidx);
					
					if(sms.equals("전송전")) {
						
						
						String bidx = sqlSession.getMapper(auctionImpl.class).maxbidx(aidx);
						
						String phone = sqlSession.getMapper(auctionImpl.class).selectsmsphone(bidx);
						
						test(phone);
						
						System.out.println(sms);
					sqlSession.getMapper(auctionImpl.class).updatemessagestatus(aidx);
					;
					String status = "낙찰중";
					auctiondto.setStatus(status);
					auctiondto.setAidx(aidx);
					/* successbiddto.setAidx(aidx); */
					
					
					System.out.println(bidx);
					biddto.setBidx(bidx);
					biddto.setBstatus("낙찰대기중");
					
					
					sqlSession.getMapper(auctionImpl.class).updateStatus(auctiondto);
					sqlSession.getMapper(auctionImpl.class).updateStatusbid(biddto);
					sqlSession.getMapper(auctionImpl.class).updateStatussuccess(biddto);
					System.out.println(aidx);
			}
	
				
		
			
			
		}
	
		System.out.println("스케쥴러 호출됩니다."+ nowTime);
		
	}
	
	@RequestMapping("acceptbid")
	public String acceptbid(@RequestParam("aidx") String aidx) {
		
		String status = "결제대기";
		auctiondto.setStatus(status);
		auctiondto.setAidx(aidx);
		/* successbiddto.setAidx(aidx); */
		
		String bidx = sqlSession.getMapper(auctionImpl.class).maxbidx(aidx);

		biddto.setBidx(bidx);
		biddto.setBstatus("낙찰");
		
		sqlSession.getMapper(auctionImpl.class).updateStatus(auctiondto);

		sqlSession.getMapper(auctionImpl.class).updateStatussuccess(biddto);
		
		return "redirect:sellList.do";
	}
	
	@RequestMapping("cancelauction")
	public String cancelauction(@RequestParam("aidx") String aidx) {
		
		
		String status = "유찰";
		auctiondto.setStatus(status);
		auctiondto.setAidx(aidx);
		/* successbiddto.setAidx(aidx); */
		
		String bidx = sqlSession.getMapper(auctionImpl.class).maxbidx(aidx);

		biddto.setBidx(bidx);
		biddto.setBstatus("유찰");
		
		sqlSession.getMapper(auctionImpl.class).updateStatus(auctiondto);

		sqlSession.getMapper(auctionImpl.class).updateStatussuccess(biddto);
		
		return "redirect:sellList.do";


	}
	
	
	@RequestMapping("auctioninsert.do")
	public String auctioninsert() {
		
		
		return "auctioninsert";
	}
	
	@RequestMapping("bidbreakdown.do")
	public String bidbreakdown(HttpServletRequest req,Model model) {
		
		HttpSession session = req.getSession();
		String mid = (String) session.getAttribute("sec_id");
	
        ArrayList<auctionDTO> bidbreakdown = sqlSession.getMapper(auctionImpl.class).bidbreakdown(mid);
        model.addAttribute("bidbreakdown", bidbreakdown);
		
		
		
		return "buylist";
	}
	
	@RequestMapping("auctionpay.do")
	public String auctionpay(HttpServletRequest req,
			@RequestParam("sum") String sum,@RequestParam("aidx") String aidx) {
		System.out.println(aidx);

		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		
		String status = "결제완료";
		auctiondto.setStatus(status);
		auctiondto.setAidx(aidx);
	
		
		String bidx = sqlSession.getMapper(auctionImpl.class).maxbidx(aidx);


		biddto.setBidx(bidx);
		String bstatus = "결제완료";
		biddto.setBstatus(bstatus);

		sqlSession.getMapper(auctionImpl.class).updateStatus(auctiondto);
		sqlSession.getMapper(auctionImpl.class).updateStatussuccess(biddto);
		sqlSession.getMapper(mainImpl.class).subtractEmoney(sum, id);
	
		return "redirect:buylist.do";
	}
	
	
	@RequestMapping("delivery.do")
	public String delivery(HttpServletRequest req,
			@RequestParam("aidx") String aidx) {


		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		
		String status = "배송중";
		auctiondto.setStatus(status);
		auctiondto.setAidx(aidx);


		String bidx = sqlSession.getMapper(auctionImpl.class).maxbidx(aidx);

		biddto.setBidx(bidx);
		String bstatus = "배송중";
		biddto.setBstatus(bstatus);
		

		sqlSession.getMapper(auctionImpl.class).updateStatus(auctiondto);
	
		sqlSession.getMapper(auctionImpl.class).updateStatussuccess(biddto);

	
		return "redirect:sellList.do";
	}
	
	@RequestMapping("completedelivery.do")
	public String completedelivery(HttpServletRequest req,
			@RequestParam("aidx") String aidx,@RequestParam("bprice") String bprice) {


		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		
		String status = "거래완료";
		auctiondto.setStatus(status);
		auctiondto.setAidx(aidx);

		
		String bidx = sqlSession.getMapper(auctionImpl.class).maxbidx(aidx);

		biddto.setBidx(bidx);
		String bstatus = "거래완료";
		biddto.setBstatus(bstatus);
		
		
		sqlSession.getMapper(auctionImpl.class).updateStatus(auctiondto);
		sqlSession.getMapper(auctionImpl.class).updateStatussuccess(biddto);
		sqlSession.getMapper(auctionImpl.class).updatepay(bprice,aidx);
	
		return "redirect:buylist.do";
	}
	
	@RequestMapping("payauction.do")
	public String payauction(HttpServletRequest req, Model model,@RequestParam("sum") String sum,
			@RequestParam("aidx") String aidx) {

		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
				
		auctiondto.setAidx(aidx);

		paydto.setId(id);
		paydto.setSum(sum);
		biddto.setAidx(aidx);
		biddto.setMid(id);
		biddto.setBprice(sum);
		
		sqlSession.getMapper(auctionImpl.class).bid(biddto);
		sqlSession.getMapper(mainImpl.class).subtractEmoney(sum, id);
		sqlSession.getMapper(auctionImpl.class).directbuy(aidx);
		sqlSession.getMapper(auctionImpl.class).updateStatusbid(biddto);
		

		String status = "결제완료";
		String bstatus = "결제완료";
		
		auctiondto.setStatus(status);
		biddto.setBstatus(bstatus);
		String bidx = sqlSession.getMapper(auctionImpl.class).maxbidx(aidx);
		System.out.println("--------------");
		System.out.println(bidx);
		biddto.setBidx(bidx);
		
		sqlSession.getMapper(auctionImpl.class).updateStatus(auctiondto);
		sqlSession.getMapper(auctionImpl.class).updateStatussuccess(biddto);
		
		return "redirect:auctionView.do?aidx="+aidx;
	}
	
	
	
	@RequestMapping(value = "auctionInsertAction.do", method = RequestMethod.POST)
    public String auctionInsertAction(
          auctionDTO auctiondto,MultipartHttpServletRequest req,
          HttpServletRequest request) {     
      HttpSession session = req.getSession();
        String mid = (String) session.getAttribute("sec_id");
        auctiondto.setMid(mid);
     //서버의 물리적경로 얻어오기
      String path=
            req.getSession().getServletContext().getRealPath("/resources/Upload");
      
      //폼값과 파일명을 저장후 View로 전달하기 위한 맵 컬렉션
      Map returnObj = new HashMap();
      try {
         //업로드폼의 file속성의 필드를 가져온다.(여기서는 2개임)
         Iterator itr = req.getFileNames();
         
         MultipartFile mfile = null;
         String fileName = "";
         List resultList = new ArrayList();
         

         /*
          물리적경로를 기반으로 File객체를 생성한 후 지정된 디렉토리가
          있는지 확인한다. 만약 없다면 mkdirs()로 생성한다. 
          */
         File directory = new File(path);
         if(!directory.isDirectory()) {
            directory.mkdirs();
            /*
             mkdir() 한 번에 하나의 디렉토리만 생성.
             mkdirs() 한 번에 여러 디렉토리를 생성.
*/
         }
         
         //업로드폼의 file필드 갯수만큼 반복
         while(itr.hasNext()) {
            //전송된 파일의 이름을 읽어온다.
            fileName=(String)itr.next();
            mfile = req.getFile(fileName);
            System.out.println("mfile="+mfile);
            
            //한글깨짐방지 처리후 전송된 파일명을 가져옴
            String originalName =
                  new String(mfile.getOriginalFilename().getBytes(),"UTF-8");
            
            //서버로 전송된 파일이 없다면 while문의 처음으로 돌아간다.
            if("".equals(originalName)) {//originalName 이 빈값이라면
               continue; //반복문 처음으로 돌아감
            }
            
            //파일명에서 확장자를 가져옴.
            String ext = originalName.substring(originalName.lastIndexOf('.'));
            //UUID를 통해 생성된 문자열과 확장자를 합쳐서 파일명 완성
            
            String saveFileName = getUuid() + ext;
            
            
            //물리적 경로에 새롭게 생성된 파일명으로 파일저장
         
            File serverFullName =
                  new File(path + File.separator + saveFileName);
            mfile.transferTo(serverFullName);//파일저장
            System.out.println(serverFullName);
            auctiondto.setAttachedfile1(saveFileName);
            sqlSession.getMapper(auctionImpl.class).auctionInsertAction(auctiondto);
         }
         
      }catch(IOException e) {
         e.printStackTrace();
      }catch(Exception e) {
         e.printStackTrace();
      }
       
       
       
       return "redirect:auctionlist.do";
    }
   public static String getUuid() {
      String uuid = UUID.randomUUID().toString();
      System.out.println("생성된UUID-1:" + uuid);
      return uuid;
   }
	


}
