package com.used.used;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import used.adminDTO;
import used.adminImpl;
import used.mainImpl;
import used.myInfoDTO;
import used.myInfoImpl;
import used.productDTO;

@Controller
public class myInfoController {  
 
	@Autowired
	private SqlSession sqlSession;
	
	myInfoDTO myInfoDTO = new myInfoDTO();
	
	@RequestMapping("myInfoview.do")
	public String myInfoview(myInfoDTO myInfoDTO,Model model,
			@RequestParam("id") String id) {
			
		myInfoDTO.setId(id);
		myInfoDTO dto = sqlSession.getMapper(myInfoImpl.class).myInfoview(myInfoDTO);
		
		model.addAttribute("dto",dto);
		
		return "myInfoview";
	}	
	
	@RequestMapping("myInfomodifyaction.do")
	public String productModifyAction(Model model, @RequestParam("id") String id) 
	{
		
		sqlSession.getMapper(myInfoImpl.class).myInfomodifyaction(id);
	
		model.addAttribute("id", id);
				
		System.out.println(id);
		
		return "redirect:index.do"; 
	}
	
/*
	@RequestMapping(value="myInfomodifyaction.do" , method=RequestMethod.POST)
	public String myInfomodifyaction(myInfoDTO myInfoDTO){
		
		sqlSession.getMapper(myInfoImpl.class).myInfomodifyaction(myInfoDTO);
		
		return "redirect:index.do";
	}	*/
	
}






















