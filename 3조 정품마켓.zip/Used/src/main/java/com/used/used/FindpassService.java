package com.used.used;

import org.apache.ibatis.session.SqlSession;

import used.mainImpl;
import used.memberDTO;

public class FindpassService {

	memberDTO memberdto = new memberDTO();

	public memberDTO execute(SqlSession sqlsession, memberDTO memberdto) throws Exception {

		memberDTO resultdto = sqlsession.getMapper(mainImpl.class).find_by_Email(memberdto);
		System.out.println(resultdto);

		if (resultdto == null) {
			throw new Exception();
			// 사용자가 입력한 아이디가 존재하지 않으면 예외 던짐.
		}
		return resultdto;

	}

}
