package com.used.used;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;


import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.scribejava.core.model.OAuth2AccessToken;

import used.cartDTO;
import used.cartlistDTO;
import used.inquiryDTO;
import used.inquiryImpl;
import used.mainImpl;
import used.memberDTO;
import used.orderdetailDTO;
import used.ordersDTO;
import used.payDTO;
import used.productDTO;

@Controller
public class MainController {
	@Autowired
	private SqlSession sqlSession;

	/////
	
	/* NaverLoginBO */
	private NaverLoginBO naverLoginBO;
	private String apiResult = null;

	@Autowired
	private void setNaverLoginBO(NaverLoginBO naverLoginBO) {
		this.naverLoginBO = naverLoginBO;
	}

	/////
	memberDTO memberDTO = new memberDTO();
	productDTO productdto = new productDTO();
	cartDTO cartdto = new cartDTO();
	cartlistDTO cartlistdto = new cartlistDTO();
	ordersDTO ordersdto = new ordersDTO();
	orderdetailDTO orderdetaildto = new orderdetailDTO();
	payDTO paydto = new payDTO();
	inquiryDTO inquirydto = new inquiryDTO();

	@RequestMapping("/home2.do")
	public String homecoming() {
		// 로고 클릭시 이동
		return "home";
		
	}

	@RequestMapping("/index.do")
	public String index(Model model, HttpServletRequest req, HttpSession session,
			@RequestParam("nowAddress") String nowAddress) {
		String sec_id = req.getRemoteUser();
		System.out.println(nowAddress);
		if (sec_id != null) {
			session.setAttribute("sec_id", sec_id);
		}
		ArrayList<productDTO> directListNowAddr = new ArrayList<productDTO>();

		//위치허용시
		if(nowAddress != "") {
			productdto.setAddress(nowAddress);
			directListNowAddr = sqlSession.getMapper(mainImpl.class).directListNowAddr(productdto);
		}
		// 위치허용차단시
		if (nowAddress == "") {
			directListNowAddr = sqlSession.getMapper(mainImpl.class).directList(productdto);
		}

		if (req.isUserInRole("ADMIN")) {
			return "aindex";
		}
		
		session.setAttribute("nowAddress", nowAddress);

		model.addAttribute("directListNowAddr", directListNowAddr);
		
		
		String id = (String) session.getAttribute("sec_id");
		if(id !=null) {
		String emoney = sqlSession.getMapper(mainImpl.class).emoney(id);
		
		session.setAttribute("emoney1", emoney);
		}

		return "index";
	}

	@RequestMapping("/login.do")
	public ModelAndView login(Model model, HttpServletRequest req, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		String kakaoUrl = KaKaoController.getAuthorizationUrl(session);
		String naverUrl = naverLoginBO.getAuthorizationUrl(session);
		mav.setViewName("login");
		// 카카오 로그인
		mav.addObject("kakao_url", kakaoUrl);
		// 네이버 로그인
		mav.addObject("naver_url", naverUrl);

		return mav;
	}
	@RequestMapping(value = "/kakaologin", produces = "application/json", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView kakaoLogin(@RequestParam("code") String code, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		ModelAndView mav = new ModelAndView(); // 결과값을 node에 담아줌
		JsonNode node = KaKaoController.getAccessToken(code); // accessToken에 사용자의 로그인한 모든 정보가 들어있음
		JsonNode accessToken = node.get("access_token"); // 사용자의 정보
		JsonNode userInfo = KaKaoController.getKakaoUserInfo(accessToken);
		String kemail = null;
		String kname = null;
		String kgender = null;
		String kbirthday = null;
		String kage = null;
		String kimage = null;
		System.out.println(userInfo);
		memberDTO memberDTO = new memberDTO();

		// 유저정보 카카오에서 가져오기 Get properties
		JsonNode properties = userInfo.path("properties");
		JsonNode kakao_account = userInfo.path("kakao_account");
		kemail = kakao_account.path("email").asText();
		kname = properties.path("nickname").asText();
		kimage = properties.path("profile_image").asText();
		kgender = kakao_account.path("gender").asText();
		kbirthday = kakao_account.path("birthday").asText();
		kage = kakao_account.path("age_range").asText();
		session.setAttribute("sec_id", kemail);
		session.setAttribute("kname", kname);
		session.setAttribute("kimage", kimage);
		session.setAttribute("kgender", kgender);
		session.setAttribute("kbirthday", kbirthday);
		session.setAttribute("kage", kage);
		System.out.println(kemail + "<>" + kname);
		mav.setViewName("home");

		if(sqlSession.getMapper(mainImpl.class).socialEmail(kemail)!=null) {
		}
		else {
			memberDTO.setId(kemail);
			memberDTO.setName(kname);
			memberDTO.setGrade("USER");
			sqlSession.getMapper(mainImpl.class).socialInsert(memberDTO);
			sqlSession.getMapper(mainImpl.class).regipay(kemail);
		}
		List<GrantedAuthority> roles = new ArrayList<GrantedAuthority>(1);
		roles.add(new SimpleGrantedAuthority("ROLE_USER"));
		User user = new User(kemail, "", roles);
		Authentication auth = new UsernamePasswordAuthenticationToken(user, null, roles);
		SecurityContextHolder.getContext().setAuthentication(auth);
		return mav;

	}

	// 네이버 로그인 성공시 callback호출 메소드
	@RequestMapping(value = "/callback", method = { RequestMethod.GET, RequestMethod.POST })
	public String callback(Model model, @RequestParam String code, @RequestParam String state, HttpSession session)
			throws IOException, org.json.simple.parser.ParseException {

		System.out.println("여기는 callback");
		OAuth2AccessToken oauthToken;
		oauthToken = naverLoginBO.getAccessToken(session, code, state);
		// 로그인 사용자 정보를 읽어온다.
		apiResult = naverLoginBO.getUserProfile(oauthToken);

		JSONParser parser = new JSONParser();
		Object obj = parser.parse(apiResult);
		org.json.simple.JSONObject jsonObj = (org.json.simple.JSONObject) obj;
		org.json.simple.JSONObject response_obj = (org.json.simple.JSONObject) jsonObj.get("response");
		// 네이버에서 설정된 사용자 이름
		String naverName = (String) response_obj.get("name");
		// 네이버에서 설정된 이메일
		String naverEmail = (String) response_obj.get("email");
        model.addAttribute("result", apiResult);
        
        session.setAttribute("sec_id", naverEmail);
        session.setAttribute("naverName",naverName);
    
    	if(sqlSession.getMapper(mainImpl.class).socialEmail(naverEmail)!=null) {
		}
		else {
			memberDTO.setId(naverEmail);
			memberDTO.setName(naverName);
			memberDTO.setGrade("USER");
			sqlSession.getMapper(mainImpl.class).socialInsert(memberDTO);
		}
        /* 네이버 로그인 성공 페이지 View 호출 */
    	List<GrantedAuthority> roles = new ArrayList<GrantedAuthority>(1);
		roles.add(new SimpleGrantedAuthority("ROLE_USER"));
		User user = new User(naverEmail, "", roles);
		Authentication auth = new UsernamePasswordAuthenticationToken(user, null, roles);
		SecurityContextHolder.getContext().setAuthentication(auth);
        return "home";
    
		/* 네이버 로그인 성공 페이지 View 호출 */

	}
	@RequestMapping("notice.do")
	public String notice(Model model, HttpServletRequest req) {

		return "notice";
	}

	@RequestMapping("boardList.do")
	public String boardList(Model model, HttpServletRequest req) {

		return "boardList";
	}

	@RequestMapping("review.do")
	public String review(Model model, HttpServletRequest req) {

		return "review";
	}

	@RequestMapping("faq.do")
	public String faq(Model model, HttpServletRequest req) {

		return "faq";
	}

	
	@RequestMapping("registration.do")
	public String registration(Model model, HttpServletRequest req) {

		return "registration";
	}

	@RequestMapping("find_idpw.do")
	public String find_idpw(Model model, HttpServletRequest req) {

		return "find_idpw";
	}

	@RequestMapping("auction.do")
	public String auction(Model model, HttpServletRequest req) {

		return "auction";
	}
	
	@RequestMapping("memberEdit.do")
	public String memberEdit(Model model, HttpServletRequest req) {

		return "memberEdit";
	}

	@RequestMapping("logout.do")
	public String logout(Model model, HttpServletRequest req) {

		return "logout";
	}

	//1대1문의 매핑
	@RequestMapping("inquiry.do")
	public String service(Model model, HttpServletRequest req) {

		return "inquiry";
	}
	
	//1대1문의 글쓰기처리
		@RequestMapping(value = "inquiryWriteAction.do", method=RequestMethod.POST)
		public String writeAction(Model model, HttpServletRequest request, inquiryDTO inquirydto,
				MultipartHttpServletRequest req) {
			
			System.out.println("글쓰기 매핑 확인 ");
					
			HttpSession session = request.getSession();
			String id = (String) session.getAttribute("sec_id");
			inquirydto.setSender(id);
			sqlSession.getMapper(inquiryImpl.class).inquiryWrite(inquirydto);
			
			
			return "redirect:inquirylist.do";
		}
		
		//1대1문의 리스트
		@RequestMapping("inquirylist.do")
		public String inquiry(Model model, HttpServletRequest req) {
			
			inquiryDTO inquiry = new inquiryDTO();

			ArrayList<inquiryDTO> lists =
					sqlSession.getMapper(inquiryImpl.class)
						.inquirylist(inquiry);

			// model객체에 담아준다!
			model.addAttribute("lists", lists);

			return "inquirylist";
		}
		
		//1대1문의 상세보기
		@RequestMapping("inquiryView.do")
		public String inquiryView(Model model, HttpServletRequest req, @RequestParam("idx") String idx) 
		{

			inquirydto.setIdx(idx);
			
			inquiryDTO inquiryView = sqlSession.getMapper(inquiryImpl.class).inquiryView(inquirydto);

			model.addAttribute("inquiryView", inquiryView);

			return "inquiryView";

		}

	
//	member
	@RequestMapping(value = "registrationaction.do", method = RequestMethod.POST)
	public String registrationaction(memberDTO memberdto, HttpServletRequest req) {
		String[] addarr = { req.getParameter("zipcode"), req.getParameter("address"), req.getParameter("address2") };
		String address = "";

		for (String string : addarr) {
			address += string + "-";
		}
		memberdto.setAddress(address);
		String id = memberdto.getId();

		sqlSession.getMapper(mainImpl.class).registration(memberdto);
		sqlSession.getMapper(mainImpl.class).regipay(id);

		return "redirect:login.do";

	}

	@RequestMapping("my.do")
	public String my(HttpServletRequest req, Model model) {

		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");

		String emoney = sqlSession.getMapper(mainImpl.class).emoney(id);

		session.setAttribute("emoney1", emoney);

		model.addAttribute("emoney", emoney);

		return "my";
	}

	@RequestMapping("pay2.do")
	public String pay(@RequestParam("sum") String sum, Model model, @RequestParam("flag") int flag) {
		System.out.println(sum);
		System.out.println(flag);

		model.addAttribute("sum", sum);
		model.addAttribute("flag", flag);

		return "pay2";
	}

	@RequestMapping("charge.do")
	public String charge(@RequestParam("sum") String sum, Model model, HttpServletRequest req,
			@RequestParam("flag") int flag) {

		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");

		paydto.setId(id);
		paydto.setSum(sum);

		System.out.println(id);

		sqlSession.getMapper(mainImpl.class).charge(paydto);
		ArrayList<Integer> price = sqlSession.getMapper(mainImpl.class).cartsum(id);
		
		int result = 0;
		for(int a : price) {
			result += a;
		}
		
		if (flag == 0) {
			return "redirect:my.do";
		} else {
			return "redirect:buyview.do?sum=" + result;
		}
	}

	@Autowired
	private JavaMailSender mailSender;
	
	@RequestMapping(value="/mailCheck", method=RequestMethod.GET)
    @ResponseBody
    public String mailCheckGET(String email) throws Exception{
       
        /* 뷰(View)로부터 넘어온 데이터 확인 */
      
        System.out.println("이메일 데이터 전송 확인");
        System.out.println("인증번호: " + email);
              
        Random random = new Random();
        //- 111111 ~ 999999 범위의 숫자를 얻기 위해서 nextInt(888888) + 111111를 사용
        int checkNum = random.nextInt(888888) + 111111;
        System.out.println("인증번호 "+checkNum);
        
        String setFrom = "gangmin4853@gmail.com"; //자신의 이메일 계정
        String toMail = email; // 수신받을 이메일
        String title = "회원가입 인증 이메일입니다."; // 자신이 보낼 이메일 제목
        String content =  // 자신이 보낼 이메일 내용
        		"홈페이지를 방문해주셔서 감사합니다. "
        		+ "<br><br>"
        		+ "인증번호는 " + checkNum + "입니다."+
        		"<br>"
        		+ "해당 인증번호를 인증번호 확인란에 기입하여 주세요.";
        
        try {
            
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "utf-8");
            helper.setFrom(setFrom);
            helper.setTo(toMail);
            helper.setSubject(title);
            helper.setText(content,true);
            mailSender.send(message);
            
        }catch(Exception e) {
            e.printStackTrace();
        }
        

        String num = Integer.toString(checkNum);

        return num;
	}

	
	@RequestMapping(value="find_pass.do", method = RequestMethod.POST)
    public String find_pass(Model model,memberDTO memberdto,RedirectAttributes redirectattr,Errors errors) {
        model.addAttribute("validate", "");
		new FindPassValidator().validate(memberdto, errors);
        if(errors.hasErrors()) {
        	model.addAttribute("validate", "yes");
            return "find_idpw";
        }
        FindpassService service = new FindpassService();
   
        try {
       
            memberDTO resultDto = service.execute(sqlSession, memberdto);
            redirectattr.addFlashAttribute("resultDto",resultDto); 
            return "redirect:sendpass";
        }
        catch(Exception e)
        {
      
        	model.addAttribute("validate", "yes");
        	e.printStackTrace();
            return "find_idpw"; 
        }
        
    }
	
	@RequestMapping(value="find_id.do", method = RequestMethod.POST)
    public String find_id(Model model,memberDTO memberdto,RedirectAttributes redirectattr,Errors errors) {
        model.addAttribute("validate", "");
		new FindPassValidator().validate(memberdto, errors);
        if(errors.hasErrors()) {
        	model.addAttribute("validate", "yes");
            return "find_idpw";
        }
        FindIdService service = new FindIdService();
   
        try {
       
            memberDTO resultDto = service.execute(sqlSession, memberdto);
            redirectattr.addFlashAttribute("resultDto",resultDto); 
            return "redirect:sendid";
        }
        catch(Exception e)
        {
      
        	model.addAttribute("validate", "yes");
        	e.printStackTrace();
            return "find_idpw"; 
        }
        
    }

	
	@Autowired
    JavaMailSender mailSender2; //root-context에서 생성한 google mailsender 빈
    
    // mailSending 코드
      @RequestMapping(value = "/sendpass")
      public void mailSending(Model model,HttpServletResponse response) throws IOException {
        Map<String, Object> map = model.asMap();
        memberDTO memberdto = (memberDTO)map.get("resultDto");
        
        System.out.println(memberdto.getEmail());
        System.out.println(memberdto.getId());
        String setfrom = "gangmin4853@gmail.com";         
        String tomail  = memberdto.getEmail();     // 받는 사람 이메일
        String title   = memberdto.getName() + "님의 아이디와 비밀번호 입니다.";      // 제목
        String content = memberdto.getName() + "님의 아이디는 " 
                            + memberdto.getId()
                            + " 비밀번호는 "
                            + memberdto.getPass()
                            + " 입니다.";    // 내용
       
        try {
          MimeMessage message = mailSender2.createMimeMessage();
          MimeMessageHelper messageHelper  = new MimeMessageHelper(message, true, "UTF-8"); //두번째 인자 true여야 파일첨부 가능.
     
          messageHelper.setFrom(setfrom);  // 보내는사람 생략하거나 하면 정상작동을 안함
          messageHelper.setTo(tomail);     // 받는사람 이메일
          messageHelper.setSubject(title); // 메일제목은 생략이 가능하다
          messageHelper.setText(content);  // 메일 내용
          mailSender2.send(message);
          response.setContentType("text/html; charset=UTF-8");
          PrintWriter out = response.getWriter();
          out.println("<script>alert('성공적으로 메일을 발송했습니다.');location.href='login.do';</script>");
          out.flush();
 
 
        } catch(Exception e){
        	response.setContentType("text/html; charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('메일발송에 실패했습니다.');history.go(-1);</script>");
            out.flush();
          System.out.println(e);
        }    
	}
	@RequestMapping(value="idchk.do", method=RequestMethod.POST)
	//https://lsk925.tistory.com/32 데이터타입이 json이나 text나 어떤것이든 결과값이 나오려면 ResponseBody를 붙여줘야된다.
	@ResponseBody
	public String idchkaction(memberDTO memberdto, HttpServletRequest req) {
		return Integer.toString(sqlSession.getMapper(mainImpl.class).idchk(memberdto));
		
	}
	
//product	
      @Autowired
      JavaMailSender mailSender3; //root-context에서 생성한 google mailsender 빈
      
      // mailSending 코드
        @RequestMapping(value = "/sendid")
        public void idmailSending(Model model,HttpServletResponse response) throws IOException {
          Map<String, Object> map = model.asMap();
          memberDTO memberdto = (memberDTO)map.get("resultDto");
          
          System.out.println(memberdto.getEmail());
          System.out.println(memberdto.getId());
          String setfrom = "gangmin4853@gmail.com";         
          String tomail  = memberdto.getEmail();     // 받는 사람 이메일
          String title   = memberdto.getName() + "님의 아이디 입니다.";      // 제목
          String content = memberdto.getName() + "님의 아이디는 " 
                              + memberdto.getId()
                              + " 입니다. ";
                        
         
          try {
            MimeMessage message = mailSender3.createMimeMessage();
            MimeMessageHelper messageHelper  = new MimeMessageHelper(message, true, "UTF-8"); //두번째 인자 true여야 파일첨부 가능.
       
            messageHelper.setFrom(setfrom);  // 보내는사람 생략하거나 하면 정상작동을 안함
            messageHelper.setTo(tomail);     // 받는사람 이메일
            messageHelper.setSubject(title); // 메일제목은 생략이 가능하다
            messageHelper.setText(content);  // 메일 내용
            mailSender3.send(message);
            response.setContentType("text/html; charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('성공적으로 메일을 발송했습니다.');location.href='login.do';</script>");
            out.flush();
   
   
          } catch(Exception e){
          	response.setContentType("text/html; charset=UTF-8");
              PrintWriter out = response.getWriter();
              out.println("<script>alert('메일발송에 실패했습니다.');history.go(-1);</script>");
              out.flush();
            System.out.println(e);
          }
        }
}

