package com.used.used;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import used.mainImpl;
import used.productDTO;

@RestController
public class MultipartController {
	@Autowired
	SqlSession sqlSession;
	@RequestMapping(value = {"/android/addproduct.do"}, method = {RequestMethod.POST}, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String upload2(HttpServletRequest request) throws IOException {
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile file = multipartRequest.getFile("files");
        String newFilename = UUID.randomUUID().toString()+".jpeg";
        String path = request.getSession().getServletContext().getRealPath("/resources/Upload");
        File dbFile = new File(path+File.separator+newFilename);
        file.transferTo(dbFile);
        System.out.println(multipartRequest.getParameter("id"));
        System.out.println(multipartRequest.getParameter("title"));
        System.out.println(multipartRequest.getParameter("price"));
        System.out.println(multipartRequest.getParameter("contents"));
        System.out.println(multipartRequest.getParameter("address"));
        String id =multipartRequest.getParameter("id");
        String pname = multipartRequest.getParameter("title");
        String price = multipartRequest.getParameter("price");
        String contents = multipartRequest.getParameter("contents");
        String address = multipartRequest.getParameter("address");
        String attachedfile1 = multipartRequest.getParameter("newFilename");
        String lcategory = multipartRequest.getParameter("lcategory");
        String mcategory = multipartRequest.getParameter("mcategory");
        System.out.println(file.getOriginalFilename());
        System.out.println(lcategory);
        System.out.println(mcategory);
        productDTO dto = new productDTO();
        dto.setId(id);
        dto.setPname(pname);
        dto.setPrice(price);
        dto.setContents(contents);
        dto.setAddress(address);
        dto.setAttachedfile1(newFilename);
        dto.setTraderule("직거래");
        dto.setLcategory(lcategory);
        dto.setMcategory(mcategory);
        dto.setCount(1);
        sqlSession.getMapper(mainImpl.class).directInsertAction(dto);
        
        


        return "success-upload2";
    }
}
