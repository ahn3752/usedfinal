package com.used.used;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import used.mainImpl;
import used.memberDTO;
import used.productDTO;

@Controller
public class AndroidController {
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("androidTest.do")
	public String testjsp() {
		return "androidtest";
	}
	@RequestMapping("/android/productList.do")
	@ResponseBody
	public ArrayList<productDTO> prdList(productDTO productdto){
		System.out.println("요청들어옴");
		System.out.println(productdto.getAddress());
		ArrayList<productDTO> plist = sqlSession.getMapper(mainImpl.class).aProductList(productdto);
		return plist;
	}
	@RequestMapping("/android/Login.do")
	@ResponseBody
	public Map<String,Object> Login(memberDTO memberDTO){
		Map<String,Object> returnMap = new HashMap<String,Object>();
		
		memberDTO memberInfo = sqlSession.getMapper(mainImpl.class).androidLogin(memberDTO);
		if(memberInfo==null) {
			returnMap.put("success", false);
		}
		else {
			returnMap.put("memberInfo", memberInfo);
			returnMap.put("success",true);
		}
		return returnMap;
	}
	@RequestMapping("/android/overlapChk.do")
	@ResponseBody
	public Map<String, Object> lapChk(memberDTO memberdto){
		Map<String,Object> returnMap = new HashMap<String,Object>();
		
		if(sqlSession.getMapper(mainImpl.class).androidLapChk(memberdto)!=null) {
			returnMap.put("flag", true);
		}
		else {
			returnMap.put("flag", false);
		}
		
		return returnMap;
	}
	@RequestMapping("/android/memberInsert.do")
	@ResponseBody
	public Map<String,Object> Insert(memberDTO memberdto){
		Map<String,Object> returnMap = new HashMap<String,Object>();
		if(sqlSession.getMapper(mainImpl.class).androidInsertMember(memberdto)==0) {
			returnMap.put("success", false);
		}
		else {
			returnMap.put("success", true);
		}
		
		return returnMap;
	}
	@RequestMapping("/android/address.do")
	public String addressAPI() {
		return "androidAddress";
	}
	@RequestMapping("/android/productdetail.do")
	@ResponseBody
	public productDTO prdDetailList(productDTO productdto){
		System.out.println("상세정보 요청들어옴");
		System.out.println(productdto.getIdx());
		productDTO plist = sqlSession.getMapper(mainImpl.class).aProductDetail(productdto);
		return plist;
	}
}
