package com.used.used;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import used.aBoardDTO;
import used.adminDTO;
import used.adminImpl;
import used.auctionDTO;
import used.productDTO;

@Controller
public class adminController {
	
	@Autowired
	private SqlSession sqlSession;
	
	adminDTO admindto = new adminDTO();
	aBoardDTO aboarddto = new aBoardDTO();
	productDTO productdto = new productDTO();
	auctionDTO auctiondto = new auctionDTO();
	
	@RequestMapping("admin")
	public String adminPage() {
		
		return "aindex";
	}
	
	@RequestMapping("aMemberlist.do")
	public String aMemberlist(Model model, HttpServletRequest req) {

		ArrayList<adminDTO> memberlist = sqlSession.getMapper(adminImpl.class).memberlist(admindto);

		model.addAttribute("list", memberlist);
		
		return "amemberlist";
	}
	
	@RequestMapping("aMembermodify.do")
	public String aMembermodify(Model model, HttpServletRequest req) {
		
		String id = req.getParameter("id");
		admindto.setId(id);
		adminDTO dto = sqlSession.getMapper(adminImpl.class).view(admindto);
		
		model.addAttribute("dto",dto);
		
		return "amembermodify";
	}
	
	@RequestMapping(value="aMembermodifyaction.do" , method=RequestMethod.POST)
	public String aMembermodifyAction(adminDTO admindto){
		
		sqlSession.getMapper(adminImpl.class).membermodify(admindto);
		
		return "redirect:aMemberlist.do";
	}
	
	@RequestMapping("aMemberdelete.do")
	public String aMemberdelete(HttpServletRequest req) {
		
		String id = req.getParameter("id");
		
		sqlSession.getMapper(adminImpl.class).memberdelete(id);
		
		return "redirect:aMemberlist.do";
	}
	
	
	@RequestMapping("aBoardlist.do")
	public String aBoardlist(Model model, HttpServletRequest req) {

		String flag = req.getParameter("flag");

		aboarddto.setFlag(flag);
		
		ArrayList<aBoardDTO> boardlist = sqlSession.getMapper(adminImpl.class).boardlist(aboarddto);
		System.out.println(boardlist);
		model.addAttribute("flag",flag);
		model.addAttribute("list", boardlist);
		
		return "aboardlist";	
	}	
	
	@RequestMapping("aBoardmodify.do")
	public String aBoardmodify(Model model, HttpServletRequest req) {
		
		String idx = req.getParameter("idx");
		aboarddto.setIdx(idx);
		aBoardDTO dto = sqlSession.getMapper(adminImpl.class).boardview(aboarddto);
		
		model.addAttribute("dto",dto);
		
		return "amodify";
	}
	
	@RequestMapping(value="aBoardmodifyaction.do" , method=RequestMethod.POST)
	public String aBoardmodifyAction(aBoardDTO aboarddto, HttpServletRequest req) {
		
		String flag = req.getParameter("flag");
		
		sqlSession.getMapper(adminImpl.class).aBoardmodify(aboarddto);
		
		return "redirect:aBoardlist.do?flag="+flag;
	}
	

	@RequestMapping("aBoarddelete.do")
	public String aBoarddelete(HttpServletRequest req) {
		
		String idx = req.getParameter("idx");
		String flag = req.getParameter("flag");
		
		sqlSession.getMapper(adminImpl.class).aBoarddelete(idx);
		
		return "redirect:aBoardlist.do?flag="+flag;
	}
	
	public static String getUuid() {
		String uuid = UUID.randomUUID().toString();
		System.out.println("생성된UUID-1:"+ uuid);
		return uuid;
	}
	
	@RequestMapping("aBoardwrite.do")
	public String aBoardwrite(Model model, HttpServletRequest req) {
		return "awrite";
	}
	
	@RequestMapping(value="aBoardwriteaction.do" , method=RequestMethod.POST)
	public String aBoardwriteaction(Model model, MultipartHttpServletRequest req,
			HttpServletRequest request,
			@RequestParam("id") String id,
			@RequestParam("title") String title,
			@RequestParam("contents") String contents
			){


		String flag= request.getParameter("flag");
		String n = "";
		
		
		aboarddto.setFlag(flag);
		aboarddto.setId(id);;
		aboarddto.setTitle(title);
		aboarddto.setContents(contents);;
		
		
		//서버의 물리적경로 얻어오기
		String path=
				req.getSession().getServletContext().getRealPath("/resources/Upload");
		
		//폼값과 파일명을 저장후 View로 전달하기 위한 맵 컬렉션
		Map returnObj = new HashMap();
		try {
			//업로드폼의 file속성의 필드를 가져온다.(여기서는 2개임)
			Iterator itr = req.getFileNames();
			
			MultipartFile mfile = null;
			String fileName = "";
			List resultList = new ArrayList();
			

			/*
			 물리적경로를 기반으로 File객체를 생성한 후 지정된 디렉토리가
			 있는지 확인한다. 만약 없다면 mkdirs()로 생성한다. 
			 */
			File directory = new File(path);
			if(!directory.isDirectory()) {
				directory.mkdirs();
				/*
				 mkdir() 한 번에 하나의 디렉토리만 생성.
				 mkdirs() 한 번에 여러 디렉토리를 생성.
*/
			}
			
			//업로드폼의 file필드 갯수만큼 반복
			while(itr.hasNext()) {
				//전송된 파일의 이름을 읽어온다.
				fileName=(String)itr.next();
				mfile = req.getFile(fileName);
				
				//한글깨짐방지 처리후 전송된 파일명을 가져옴
				String originalName =
						new String(mfile.getOriginalFilename().getBytes(),"UTF-8");
				
				//서버로 전송된 파일이 없다면 while문의 처음으로 돌아간다.
				if("".equals(originalName)) {//originalName 이 빈값이라면
					continue; //반복문 처음으로 돌아감
				}
				
				//파일명에서 확장자를 가져옴.
				String ext = originalName.substring(originalName.lastIndexOf('.'));
				//UUID를 통해 생성된 문자열과 확장자를 합쳐서 파일명 완성
				
				String saveFileName = getUuid() + ext;
				
				aboarddto.setAttachedfile(saveFileName);
				//물리적 경로에 새롭게 생성된 파일명으로 파일저장
			
				File serverFullName =
						new File(path + File.separator + saveFileName);
				mfile.transferTo(serverFullName);//파일저장
				
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		sqlSession.getMapper(adminImpl.class).aBoardwrite(aboarddto);
		
		return "redirect:aBoardlist.do?flag="+flag;
	}
	@RequestMapping("aProductlist.do")
	public String aProductlist(@RequestParam("traderule") String traderule,Model model) {
		System.out.println(traderule);
		ArrayList<productDTO> list = sqlSession.getMapper(adminImpl.class).aProductlist(traderule);
		
		model.addAttribute("list", list);
		return "aProductlist";
	}
	@RequestMapping("aProductmodify.do")
	public String aProductmodify(@RequestParam("idx") String idx,Model model) {
		
		productDTO aproductmodify = sqlSession.getMapper(adminImpl.class).aProductmodify(idx);
		
		model.addAttribute("dto",aproductmodify);
		
		return "aProductmodify";
	}
	
	@RequestMapping(value="aProductmodifyaction.do", method = RequestMethod.POST)
	public String aProductmodifyaction(productDTO productdto) throws UnsupportedEncodingException {
		
		String traderule = productdto.getTraderule();
		traderule= URLEncoder.encode(traderule, "UTF-8");

		sqlSession.getMapper(adminImpl.class).aProductmodifyaction(productdto);
	
		
		return "redirect:aProductlist.do?traderule="+traderule;
	}
	@RequestMapping("aProductdelete.do")
	public String aProductdelete(@RequestParam("idx") String idx,@RequestParam("traderule")String traderule) throws UnsupportedEncodingException {
		traderule= URLEncoder.encode(traderule, "UTF-8");
		sqlSession.getMapper(adminImpl.class).aProductdelete(idx);
		
		
		return "redirect:aProductlist.do?traderule="+traderule;
	}
	
	@RequestMapping("aAuctionlist.do")
	public String aAuctionlist(Model model) {
		
		
		ArrayList<auctionDTO> aAuctionlist = sqlSession.getMapper(adminImpl.class).aAuctionlist();
		
		model.addAttribute("list",aAuctionlist);
		
		return "aAuctionlist";
	}
	@RequestMapping("aAuctionmodify.do")
	public String aAuctionmodify(@RequestParam(value="aidx", required=false) String aidx,Model model) {
		
		auctiondto.setAidx(aidx);
		
		auctionDTO aAuctionmodify = sqlSession.getMapper(adminImpl.class).aAuctionmodify(auctiondto);
		
		model.addAttribute("row",aAuctionmodify);
		
		return "aAuctionmodify";
	}
	
	@RequestMapping("aAuctionmodifyaction.do")
	public String aAuctionmodifyaction(auctionDTO auctiondto) {
		
		sqlSession.getMapper(adminImpl.class).aAuctionmodifyaction(auctiondto);
		
		
		return "redirect:aAuctionlist.do";
	}
	
	@RequestMapping("aAuctiondelete.do")
	public String aAuctiondelete(@RequestParam("aidx") String aidx) {
		
		sqlSession.getMapper(adminImpl.class).aAuctiondelete(aidx);
		
		return "redirect:aAuctionlist.do";
	}
	
}
































