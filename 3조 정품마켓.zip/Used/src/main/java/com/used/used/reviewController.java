package com.used.used;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import util.PagingUtil;
import used.commentDTO;
import used.reviewDTO;
import used.reviewImpl;

//자유게시판 컨트롤러
@Controller
public class reviewController {

	//servlet-context.xml에서 생성한 mybatis 빈을 주입받는다!(id=sqlSession)
	@Autowired
	private SqlSession sqlSession;

	// 객체 생성(reviewDTO 클래스 생성)
	reviewDTO reviewdto = new reviewDTO();	
	commentDTO commentdto = new commentDTO();	

	// 보드 리스트
	@RequestMapping("reboardList.do")
	public String reboardList(Model model, HttpServletRequest req) {
				
		
		reviewdto.setSearchField(req.getParameter("searchTxt"));
			
		//검색부분
		ArrayList<String> searchLists = null;
		
		if(req.getParameter("searchWord")!=null) {
			searchLists = new ArrayList<String>();
			//검색어는 스페이스로 구분되므로 split()을 통해 문자열배열로 반환한다.
			String[] sTxtArray = req.getParameter("searchWord").split(" ");
			//배열크기만큼 반복하면서 문자열을 컬렉션에 저장한다.
			for(String str : sTxtArray) {
				searchLists.add(str);
			}			
		}
		reviewdto.setSearchTxt(searchLists);
		System.out.println("검색어: "+searchLists);
		
		
		//게시물의 갯수 카운트 //페이징처리
		int totalRecordCount = sqlSession.getMapper(reviewImpl.class).getTotalCount(reviewdto);

		//페이지 처리를 위한 설정값
		int pageSize = 10;
		int blockPage = 5;
		//현재페이지 번호 가져오기
		int nowPage = req.getParameter("nowPage")==null ? 1 :
			Integer.parseInt(req.getParameter("nowPage"));
		//select할 게시물의 구간을 계산
		int start = (nowPage-1) * pageSize + 1;
		int end = nowPage * pageSize;
		
		//기존의 형태와는 다르게 DTO객체에 저장한 후 Mapper를 호출한다. 
		reviewdto.setStart(start);
		reviewdto.setEnd(end);		
		
		ArrayList<reviewDTO> reboardlist = sqlSession.getMapper(reviewImpl.class).listPage(reviewdto);
		
		//페이지번호 처리
	    String pagingImg =
	       PagingUtil.pagingImg(totalRecordCount, pageSize, blockPage, nowPage,
	          "/used/reboardList.do?");
	    model.addAttribute("pagingImg", pagingImg);
	    //게시물의 줄바꿈 처리
	    for(reviewDTO dto : reboardlist)
	    {
	       String temp = dto.getContents().replace("\r\n","<br/>");
	       dto.setContents(temp);
	    }
				
		String flag = "review";
		reviewdto.setFlag(flag);
		
		model.addAttribute("nowpage", nowPage);
		model.addAttribute("reboardlist", reboardlist);

		return "reboardList";
	}

	
	// 보드 상세보기 = freeboardView를 boardView.jsp의 이름값과 동일하게 한다!
	@RequestMapping("reboardView.do")
	public String reboardView(Model model, HttpServletRequest req, @RequestParam("idx") String idx) 
	{
		
		reviewdto.setIdx(idx);
		String flag = "review";
		reviewdto.setFlag(flag);
		
		int reboardHits = sqlSession.getMapper(reviewImpl.class).reboardHits(reviewdto);

		reviewDTO reboardView = sqlSession.getMapper(reviewImpl.class).reboardView(reviewdto);
		
		model.addAttribute("reboardView", reboardView);		
		
		return "reboardView";		
		
		
	}

	//보드 글쓰기
	@RequestMapping("reboardWrite.do")
	public String reboardWrite(Model model, HttpServletRequest req)
	{
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		
		model.addAttribute("id",id);


		return "reboardWrite";

	}
	
	// uuid 생성
		public static String getUuid() {
			String uuid = UUID.randomUUID().toString();
			System.out.println("생성된UUID-1:" + uuid);
			return uuid;
		}

	
	//보드 글쓰기처리
	@RequestMapping(value = "reboardWriteAction.do", method=RequestMethod.POST)
	public String writeAction(Model model, HttpServletRequest request, reviewDTO reviewdto,
			MultipartHttpServletRequest req)
	{
		
		System.out.println("글쓰기 매핑 확인 ");
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("sec_id");
		System.out.println(id);
		
		reviewdto.setId(id);
		String flag = "review";
		reviewdto.setFlag(flag);
		
		//서버의 물리적경로 얻어오기
		String path = req.getSession().getServletContext().getRealPath("/resources/Upload");
		
		System.out.println(path);
		//폼값과 파일명을 저장후 View로 전달하기 위한 맵 컬렉션
		Map returnObj = new HashMap();
		
		try {
			//업로드폼의 file속성의 필드를 가져온다.(여기서는 2개임)
			Iterator itr = req.getFileNames();
			
			MultipartFile mfile = null;
			String fileName = "";
			List resultList = new ArrayList();
			

			/*
			 물리적경로를 기반으로 File객체를 생성한 후 지정된 디렉토리가
			 있는지 확인한다. 만약 없다면 mkdirs()로 생성한다. 
			 */
			File directory = new File(path);
			if(!directory.isDirectory()) {
				directory.mkdirs();
				/*
				 mkdir() 한 번에 하나의 디렉토리만 생성.
				 mkdirs() 한 번에 여러 디렉토리를 생성.
*/
			}
			
			//업로드폼의 file필드 갯수만큼 반복
			while(itr.hasNext()) {
				//전송된 파일의 이름을 읽어온다.
				fileName=(String)itr.next();
				mfile = req.getFile(fileName);
				System.out.println("mfile="+mfile);
				
				//한글깨짐방지 처리후 전송된 파일명을 가져옴
				String originalName =
						new String(mfile.getOriginalFilename().getBytes(),"UTF-8");
				
				//서버로 전송된 파일이 없다면 while문의 처음으로 돌아간다.
				if("".equals(originalName)) {//originalName 이 빈값이라면
					continue; //반복문 처음으로 돌아감
				}
				
				//파일명에서 확장자를 가져옴.
				String ext = originalName.substring(originalName.lastIndexOf('.'));
				//UUID를 통해 생성된 문자열과 확장자를 합쳐서 파일명 완성
				
				String saveFileName = getUuid() + ext;
				
				System.out.println(saveFileName);
				
				//물리적 경로에 새롭게 생성된 파일명으로 파일저장
			
				File serverFullName =
						new File(path + File.separator + saveFileName);
				mfile.transferTo(serverFullName);//파일저장
				System.out.println(serverFullName);
				reviewdto.setAttachedfile(saveFileName);
				
				//매퍼에 작성한 쿼리문 실행 freeboardWrite를 impl, mapper id와 일치시켜야 한다.
				sqlSession.getMapper(reviewImpl.class).reboardWrite(reviewdto);
				
			}
			//첨부파일이 없으면 여기서 실행된다!
	         if(reviewdto.getAttachedfile()==null) {
	            sqlSession.getMapper(reviewImpl.class).reboardWriteNoFile(reviewdto);
	         }
	         
		}catch(IOException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		model.addAttribute("msg","작성을 완료했습니다");		
		model.addAttribute("url","/reboardList.do");
						
		return "redirect";
		
	}
	
	
	//보드 수정하기
	@RequestMapping("reboardModify.do")
	public String reboardModify(Model model, HttpServletRequest req,
			@RequestParam("idx") String idx) 
	{
		
		
		reviewdto.setIdx(idx);

		String flag = "review";
		reviewdto.setFlag(flag);

		reviewDTO reboardView = sqlSession.getMapper(reviewImpl.class).reboardView(reviewdto);

		model.addAttribute("reboardView", reboardView);
		 
		return "reboardModify"; 
	}
	 
	
	//보드 수정처리
	//form에서 날린 name값을 reviewDTO로 받아서 setter에 저장한다.
	@RequestMapping(value = "reboardModifyAction.do", method=RequestMethod.POST)
	public String reboardModifyAction(Model model, reviewDTO reviewdto)
	{	
		
		//매퍼에 작성한 쿼리문 실행 freeboardModify를 impl, mapper id와 일치시켜야 한다.
		sqlSession.getMapper(reviewImpl.class).reboardModify(reviewdto);
		
		model.addAttribute("msg","수정을 완료했습니다");		
		model.addAttribute("url","/reboardList.do");
						
		return "redirect";
	}

	
	//보드 삭제하기
	@RequestMapping("reboardDelete.do")
	public String reboardDelete(Model model, @RequestParam("idx") String idx) 
	{
		sqlSession.getMapper(reviewImpl.class).reboardDelete(idx);
		
		model.addAttribute("msg","삭제를 완료했습니다");		
		model.addAttribute("url","/reboardList.do");
						
		return "redirect";
	}
	
	
	//댓글 리스트
	@RequestMapping("commentList.do")
	public String commentList(Model model, HttpServletRequest req)
	{
		ArrayList<commentDTO> comment = sqlSession.getMapper(reviewImpl.class).commentList(commentdto);
		
		System.out.println("리스트");
		model.addAttribute("comment", comment);
		
		return "reboardList";		
	}
	//댓글 작성
	@RequestMapping("commentInsert.do")
	public String commentInsert(HttpServletRequest req) 
	{
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		
		commentdto.setWriter(id);
		
		sqlSession.getMapper(reviewImpl.class).commentInsert(commentdto);
				
		return "redirect:reboardList.do";
	}
	//댓글 수정
	@RequestMapping("commentUpdate.do")
	public String comentUpdate(HttpServletRequest req) 
	{
				
		sqlSession.getMapper(reviewImpl.class).commentUpdate(commentdto);
		
		return "redirect:reboardList.do";
	}
	//댓글 삭제	
	@RequestMapping("comentDelete.do")
	public String comentDelete(HttpServletRequest req) 
	{
				
		sqlSession.getMapper(reviewImpl.class).commentUpdate(commentdto);
		
		return "redirect:reboardList.do";
	}
	

}











