package com.used.used;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import util.PagingUtil;
import util.EnvFileReader;
import used.QnADTO;
import used.auctionDTO;
import used.auctionImpl;
import used.bidDTO;
import used.cartDTO;
import used.cartlistDTO;
import used.mainImpl;
import used.memberDTO;
import used.orderdetailDTO;
import used.ordersDTO;
import used.payDTO;
import used.productDTO;
import used.ReservationDTO;

@Controller
public class shopController {

	@Autowired
	private SqlSession sqlSession;

	productDTO productdto = new productDTO();
	cartDTO cartdto = new cartDTO();
	cartlistDTO cartlistdto = new cartlistDTO();
	ordersDTO ordersdto = new ordersDTO();
	orderdetailDTO orderdetaildto = new orderdetailDTO();
	payDTO paydto = new payDTO();
	QnADTO qnadto = new QnADTO();
	auctionDTO auctiondto = new auctionDTO();
	
	//물품등록 이동
	@RequestMapping("productinsert.do")
	public String productinsert() {
		
		return "productinsert";
	}
	//물품등록 대분류 중분류
	@RequestMapping("mselect.do")
	public String mselect() {

		return "mselect";
	}
	// 물품 list 출력
	@RequestMapping("productList.do")
	public String productList(Model model, HttpServletRequest req) {

		System.out.println("매핑확인용");
		ArrayList<productDTO> productlist = sqlSession.getMapper(mainImpl.class).productlist(productdto);

		model.addAttribute("list", productlist);
		System.out.println(productlist);

		return "productList";
	}
	
	
	@RequestMapping("mproductList.do")
	public String mproductList(Model model, HttpServletRequest req) {
		String lcategory = req.getParameter("lcategory");
		String mcategory = req.getParameter("mcategory");
		
		ArrayList<productDTO> mproductlist = sqlSession.getMapper(mainImpl.class).mproductlist(lcategory,mcategory);

		model.addAttribute("list", mproductlist);
		System.out.println(mproductlist);
		return "productList";
	}
	
	@RequestMapping("mdirectList.do")
	public String mdirectList(Model model, HttpServletRequest req) {
		String lcategory = req.getParameter("lcategory");
		String mcategory = req.getParameter("mcategory");
		
		ArrayList<productDTO> mdirectlist = sqlSession.getMapper(mainImpl.class).mdirectlist(lcategory,mcategory);

		model.addAttribute("directList", mdirectlist);
		System.out.println(mdirectlist);
		return "directList";
	}

	// 물품 상세 보기
	@RequestMapping("productView.do")
	public String productview(Model model, HttpServletRequest req, @RequestParam("idx") String idx) {

		productdto.setIdx(idx);
		System.out.println(idx);
		productDTO dto = sqlSession.getMapper(mainImpl.class).productView(productdto);
		
		model.addAttribute("dto", dto);
		req.setAttribute("sellerid", dto.getId());
		return "productView";
	}
	@RequestMapping("qnaList.do")
	public String qnaList(Model model, HttpServletRequest req,@RequestParam("idx")String idx) {
		
		//상품문의
		qnadto.setProductNum(idx);
	
		int totalRecordCount = sqlSession.getMapper(mainImpl.class).getTotalCount(qnadto);
		int pageSize=4;
		int blockPage=2;
		//페이지수를 계산
		int totalPage = (int)Math.ceil((double)totalRecordCount/pageSize);
		//현제페이지번호. 첫 진입일때는 무조건 1페이지로 지정
		int nowPage = req.getParameter("nowPage")==null?1:Integer.parseInt(req.getParameter("nowPage"));
		//리스트에 출력할 게시물의 구간을 계산(select절의 between에 사용)
		int start = (nowPage-1) * pageSize +1;
		int end = nowPage * pageSize;
		//가상번호 계산하여 부여하기
		int virtualNum = 0;
		int countNum = 0;
		
		qnadto.setStart(start);
		qnadto.setEnd(end);
		
		ArrayList<QnADTO> qnalist = sqlSession.getMapper(mainImpl.class).qnaList(qnadto);
		for(QnADTO row : qnalist) {
			virtualNum = totalRecordCount - (((nowPage-1)*pageSize)+countNum++);
			//setter를 통해 저장
			row.setVirtualNum(virtualNum);
			String reSpace="";
			if(row.getBindent()>0) {
				for(int i=0;i<row.getBindent();i++) {
					reSpace+="&nbsp;&nbsp;";
				}
				row.setQnaTitle(reSpace
						+"<img src='./images/re3.gif'>"
						+row.getQnaTitle());
			}
		}
		
		String pagingImg = 
				PagingUtil.pagingAjax(totalRecordCount, pageSize, blockPage, nowPage, "");
		model.addAttribute("idx",idx);
		model.addAttribute("nowPage",nowPage);
		model.addAttribute("pagingImg", pagingImg);
		model.addAttribute("qnalist", qnalist);
		
		return "qnaList";
	}
	//직거래 물품 상세 보기
	@RequestMapping("directproductView.do")
	public String directproductview(Model model, HttpServletRequest req,@RequestParam("idx") String idx) {

		model.addAttribute("reservation", "no");
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		if(id==null) id = "";
    	String cnt = sqlSession.getMapper(mainImpl.class).checkReservation(id,idx);
    	if(!cnt.equals("0")) {
    		model.addAttribute("reservation", "yes");
    	}
		productdto.setIdx(idx);
		productDTO dto = sqlSession.getMapper(mainImpl.class).productView(productdto);
		
		
		System.out.println(dto);
		model.addAttribute("dto",dto);
		
		
		return "directproductView";
	}
	//직거래 장터
	@RequestMapping("directList.do")
	public String directList(Model model, HttpServletRequest req) {
		HttpSession session = req.getSession();
		String nowAddress= (String)session.getAttribute("nowAddress");
		System.out.println(nowAddress);
		ArrayList<productDTO> directList = new ArrayList<productDTO>();
		directList=sqlSession.getMapper(mainImpl.class).directList(productdto);
		model.addAttribute("directList", directList);
		return "directList";
	}
	//직거래 장터 물품등록 이동
	@RequestMapping("directinsert.do")
	public String directinsert() {
		return "directinsert";
	}
	// 장바구니 담기
	@RequestMapping(value = "cartaction.do", method = RequestMethod.POST)
	public String cart(cartDTO cartdto, Model model, HttpServletRequest req, Authentication authentication,
			@RequestParam("flag") String flag, @RequestParam("idx") String idx) {

		String id = (String) req.getParameter("id");
		
		cartdto.setId(id);
		sqlSession.getMapper(mainImpl.class).cart(cartdto);

		System.out.println(flag);

		if (flag.equals("2")) {
			return "redirect:cartlist.do";
		} else {
			return "redirect:productView.do?idx=" + idx;
		}
	}

	// 장바구니 list출력
	@RequestMapping("cartlist.do")
	public String cartlist(cartDTO cartdto, Model model,HttpServletRequest req) {

		HttpSession session = req.getSession();
	
		String id = (String) session.getAttribute("sec_id");
		cartlistdto.setId(id);
		ArrayList<cartlistDTO> cartlist = sqlSession.getMapper(mainImpl.class).cartList(cartlistdto);

		model.addAttribute("cartlist", cartlist);

		return "cart";

	}

	// 장바구니 삭제
	@RequestMapping("deletecart.do")
	public String deletecart(@RequestParam(value = "chbox[]") List<String> chArr, cartDTO cartdto) {

		String id = cartdto.getId();
		for (String i : chArr) {
			String cidx = i;
			cartdto.setCidx(cidx);

			sqlSession.getMapper(mainImpl.class).deletecart(cartdto);
		}

		return "redirect:cartlist.do?id=" + id;

	}

	// 장바구니 물품 수량 변경
	@RequestMapping(value = "cartupdate.do", method = RequestMethod.POST)
	public String cartupdate(cartDTO cartdto, HttpServletRequest req) {
		
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		System.out.println(id);
		cartdto.setId(id);
		sqlSession.getMapper(mainImpl.class).cartupdate(cartdto);

		return "redirect:cartlist.do?id=" + id;
	}

	// 주문하기 창 출력
	@RequestMapping("buyview.do")
	public String buyview(Model model, @RequestParam("sum") String sum,
			HttpServletRequest req) {
		
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		
		String emoney = sqlSession.getMapper(mainImpl.class).emoney(id);
		
		model.addAttribute("sum", sum);
		model.addAttribute("emoney", emoney);
		session.setAttribute("emoney1", emoney);

		return "buy";
	}

	// uuid 생성
	public static String getUuid() {
		String uuid = UUID.randomUUID().toString();
		System.out.println("생성된UUID-1:" + uuid);
		return uuid;
	}


	
	//구매하기
	@RequestMapping(value = "buy.do", method = RequestMethod.POST)
	public String buy(ordersDTO ordersdto, orderdetailDTO orderdetaildto, HttpServletRequest req, Model model,
			@RequestParam("sum") String sum, @RequestParam("id") String id){
		
		HttpSession session = req.getSession();
		
		paydto.setId(id);
		paydto.setSum(sum);
	
		
		String ordernum = getUuid();

		ordersdto.setOrdernum(ordernum);
		ordersdto.setSum(sum);

		orderdetaildto.setOrdernum(ordernum);
		
		// 주문내역 insert
		sqlSession.getMapper(mainImpl.class).orders(ordersdto);
		// 주문상세내역 insert
		sqlSession.getMapper(mainImpl.class).orderdetail(orderdetaildto);
		// 주문완료후 카트에 저장된 목록 삭제
		sqlSession.getMapper(mainImpl.class).cartdelete(id);
		//e-money 차감
		sqlSession.getMapper(mainImpl.class).subtractEmoney(sum, id);
		
		String idx = sqlSession.getMapper(mainImpl.class).orderdetailidx(ordernum);
		
		
		return "redirect:orderlist.do?idx="+idx;

	}

	// 주문한 내역 출력
		@RequestMapping("orderlist.do")
		public String orderlist(Model model, @RequestParam("idx") String idx, HttpServletRequest req) {
			System.out.println(idx);
			HttpSession session = req.getSession();
			String id = (String) session.getAttribute("sec_id");
			String ordernum = sqlSession.getMapper(mainImpl.class).ordernum(idx);
			ordersdto.setOrdernum(ordernum);
			ArrayList<ordersDTO> orderlist = sqlSession.getMapper(mainImpl.class).orderlist(ordersdto);
			ArrayList<orderdetailDTO> sellerprice = sqlSession.getMapper(mainImpl.class).sellerprice(idx);
			

			for(orderdetailDTO s : sellerprice) {
			
			
				String sid = s.getSellerid();
				int price = Integer.parseInt(s.getPrice());
				int count = s.getCount();
				int sum = price*count;
				
				sqlSession.getMapper(mainImpl.class).sellerreward(sum,sid);
				
			}
			
			String emoney = sqlSession.getMapper(mainImpl.class).emoney(id);
			
			session.setAttribute("emoney1", emoney);
		
			model.addAttribute("orderlist", orderlist);

			return "orderlist";
		}
	//구매내역
	@RequestMapping("buylist.do")
	public String buylist(HttpServletRequest req, Model model) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		ordersdto.setId(id);
		ArrayList<ReservationDTO> reservation = sqlSession.getMapper(mainImpl.class).getReservation(id);
		ArrayList<productDTO> dProduct = sqlSession.getMapper(mainImpl.class).dProductbuyList(id);
		ArrayList<ordersDTO> buylist = sqlSession.getMapper(mainImpl.class).buylist(ordersdto);
		String mid = (String) session.getAttribute("sec_id");
        ArrayList<auctionDTO> bidbreakdown = sqlSession.getMapper(auctionImpl.class).bidbreakdown(id);
        model.addAttribute("rlist", reservation);
		model.addAttribute("dProduct", dProduct);
		String emoney = sqlSession.getMapper(mainImpl.class).emoney(id);
        model.addAttribute("bidbreakdown", bidbreakdown);
		model.addAttribute("buylist", buylist);
		model.addAttribute("emoney",emoney);
		session.setAttribute("emoney1", emoney);
		return "buylist";
	}
	//판매내역
	@RequestMapping("sellList.do")
	public String sellist(HttpServletRequest req, Model model) {
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		ordersdto.setId(id);
		ArrayList<productDTO> dProduct = sqlSession.getMapper(mainImpl.class).dProductList(id);
		ArrayList<ordersDTO> selllist = sqlSession.getMapper(mainImpl.class).selllist(ordersdto);
		ArrayList<productDTO> allproduct = sqlSession.getMapper(mainImpl.class).allproduct(id);
		ArrayList<auctionDTO> sellauction = sqlSession.getMapper(mainImpl.class).sellauction(id);

		model.addAttribute("dProduct", dProduct);
		model.addAttribute("allproduct", allproduct);
		model.addAttribute("selllist", selllist);
		model.addAttribute("sellauction", sellauction);
		
		return "sellList";
	}
	//판매 상세 내역
	@RequestMapping("buylistdetail.do")
	public String buylistdetail(@RequestParam("ordernum") String ordernum, Model model) {

		System.out.println(ordernum);
		ordersdto.setOrdernum(ordernum);

		ArrayList<ordersDTO> buylistdetail = sqlSession.getMapper(mainImpl.class).buylistdetail(ordersdto);
		


		model.addAttribute("buylistdetail", buylistdetail);
		model.addAttribute("ordernum", ordernum);


		return "buylistdetail";
	}
	//주문 상태변경
	@RequestMapping("updatestatus.do")
	public String updatestatus(@RequestParam("cidx") String cidx, @RequestParam("status") String status,
			@RequestParam("pidx") String pidx, @RequestParam("count") int count,
			@RequestParam("ordernum") String ordernum) {
		
		System.out.println("매핑테스트");
		System.out.println(status);
		System.out.println(cidx);
		orderdetaildto.setCidx(cidx);
		orderdetaildto.setStatus(status);
		productdto.setCount(count);
		productdto.setIdx(pidx);

		sqlSession.getMapper(mainImpl.class).updatestatus(orderdetaildto);
		sqlSession.getMapper(mainImpl.class).updatepcount(productdto);
		ArrayList<String> idx = sqlSession.getMapper(mainImpl.class).checkcount();

		for (String id : idx) {
			sqlSession.getMapper(mainImpl.class).dropproduct(id);
		}
		
		if(status.equals("거래완료")) {
	
			return "redirect:buylistdetail.do?ordernum="+ordernum;

		}
	
		return "redirect:sellList.do";
	}

	// 카트에 저장된 숫자 카운트
	@ResponseBody
	@RequestMapping(value = "cartcount.do", method = RequestMethod.POST)
	public String cartcount(Model model, HttpServletRequest req) {
		String cartcount = null; 
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		if(id!=null) {
			cartcount = sqlSession.getMapper(mainImpl.class).cartcount(id);
		}
		session.setAttribute("cartcount", cartcount);
		
		return cartcount;

	}
	
		//ckeditor 이미지 업로드
	  @RequestMapping(value="imgupload.do", method = RequestMethod.POST)
	    public void imageUpload(HttpServletRequest request,
	            HttpServletResponse response
	            , @RequestParam MultipartFile upload) throws Exception{
		  
		  System.out.println("멀티파트");
	        // 랜덤 문자 생성
	        UUID uid = UUID.randomUUID();
	        
	        OutputStream out = null;
	        PrintWriter printWriter = null;
	        
	        //인코딩
	        response.setCharacterEncoding("utf-8");
	        response.setContentType("text/html;charset=utf-8");
	        
	        try{
	            
	            //파일 이름 가져오기
	            String fileName = upload.getOriginalFilename();
	            byte[] bytes = upload.getBytes();
	            
	            //이미지 경로 생성
	            String path = "C:\\02Workspaces\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\Used\\resources\\Upload\\";// fileDir는 전역 변수라 그냥 이미지 경로 설정해주면 된다.
	            String ckUploadPath = path + uid + "_" + fileName;
	            File folder = new File(path);
	            
	            //해당 디렉토리 확인
	            if(!folder.exists()){
	                try{
	                    folder.mkdirs(); // 폴더 생성
	                }catch(Exception e){
	                    e.getStackTrace();
	                }
	            }
	            
	            out = new FileOutputStream(new File(ckUploadPath));
	            out.write(bytes);
	            out.flush(); // outputStram에 저장된 데이터를 전송하고 초기화
	            
	            String callback = request.getParameter("CKEditorFuncNum");
	            printWriter = response.getWriter();
	            String fileUrl = "ckImgSubmit.do?uid=" + uid + "&fileName=" + fileName;  // 작성화면
	            
	        // 업로드시 메시지 출력
	          printWriter.println("{\"filename\" : \""+fileName+"\", \"uploaded\" : 1, \"url\":\""+fileUrl+"\"}");
	          printWriter.flush();
	            
	        }catch(IOException e){
	            e.printStackTrace();
	        } finally {
	          try {
	           if(out != null) { out.close(); }
	           if(printWriter != null) { printWriter.close(); }
	          } catch(IOException e) { e.printStackTrace(); }
	         }
	        
	        return;
	    }
	    
	    /**
	     * cKeditor 서버로 전송된 이미지 뿌려주기
	     * @param uid
	     * @param fileName
	     * @param request
	     * @return
	     * @throws ServletException
	     * @throws IOException
	     */
	    //
	    @RequestMapping(value="ckImgSubmit.do")
	    public void ckSubmit(@RequestParam(value="uid") String uid
	                            , @RequestParam(value="fileName") String fileName
	                            , HttpServletRequest request, HttpServletResponse response
	                           )
	 throws ServletException, IOException{
	        System.out.println("멀티파트2");
	        //서버에 저장된 이미지 경로
	        String path = "C:\\02Workspaces\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\Used\\resources\\Upload\\";
	    
	        String sDirPath = path + uid + "_" + fileName;
	        
	        File imgFile = new File(sDirPath);
	        
	        //사진 이미지 찾지 못하는 경우 예외처리로 빈 이미지 파일을 설정한다.
	        if(imgFile.isFile()){
	            byte[] buf = new byte[1024];
	            int readByte = 0;
	            int length = 0;
	            byte[] imgBuf = null;
	            
	            FileInputStream fileInputStream = null;
	            ByteArrayOutputStream outputStream = null;
	            ServletOutputStream out = null;
	         
	            try{
	                fileInputStream = new FileInputStream(imgFile);
	                outputStream = new ByteArrayOutputStream();
	                out = response.getOutputStream();
	                
	                while((readByte = fileInputStream.read(buf)) != -1){
	                    outputStream.write(buf, 0, readByte);
	                }
	                
	                imgBuf = outputStream.toByteArray();
	                length = imgBuf.length;
	                out.write(imgBuf, 0, length);
	                out.flush();
	                
	            }catch(IOException e){
	               e.printStackTrace();
	            }finally {
	                outputStream.close();
	                fileInputStream.close();
	                out.close();
	            }
	        }
	    }
	    

    @RequestMapping(value = "productInsertAction.do", method = RequestMethod.POST)
    public String productInsertAction(
    		productDTO productdto,MultipartHttpServletRequest req,
    		HttpServletRequest request) {  	
    	
   
    	String traderule ="온라인거래";
    	productdto.setTraderule(traderule);
  
   
     //서버의 물리적경로 얻어오기
		String path=
				req.getSession().getServletContext().getRealPath("/resources/Upload");
		
		//폼값과 파일명을 저장후 View로 전달하기 위한 맵 컬렉션
		Map returnObj = new HashMap();
		try {
			//업로드폼의 file속성의 필드를 가져온다.(여기서는 2개임)
			Iterator itr = req.getFileNames();
			
			MultipartFile mfile = null;
			String fileName = "";
			List resultList = new ArrayList();
			

			/*
			 물리적경로를 기반으로 File객체를 생성한 후 지정된 디렉토리가
			 있는지 확인한다. 만약 없다면 mkdirs()로 생성한다. 
			 */
			File directory = new File(path);
			if(!directory.isDirectory()) {
				directory.mkdirs();
				/*
				 mkdir() 한 번에 하나의 디렉토리만 생성.
				 mkdirs() 한 번에 여러 디렉토리를 생성.
*/
			}
			
			//업로드폼의 file필드 갯수만큼 반복
			while(itr.hasNext()) {
				//전송된 파일의 이름을 읽어온다.
				fileName=(String)itr.next();
				mfile = req.getFile(fileName);
				System.out.println("mfile="+mfile);
				
				//한글깨짐방지 처리후 전송된 파일명을 가져옴
				String originalName =
						new String(mfile.getOriginalFilename().getBytes(),"UTF-8");
				
				//서버로 전송된 파일이 없다면 while문의 처음으로 돌아간다.
				if("".equals(originalName)) {//originalName 이 빈값이라면
					continue; //반복문 처음으로 돌아감
				}
				
				//파일명에서 확장자를 가져옴.
				String ext = originalName.substring(originalName.lastIndexOf('.'));
				//UUID를 통해 생성된 문자열과 확장자를 합쳐서 파일명 완성
				
				String saveFileName = getUuid() + ext;
				
				
				//물리적 경로에 새롭게 생성된 파일명으로 파일저장
			
				File serverFullName =
						new File(path + File.separator + saveFileName);
				mfile.transferTo(serverFullName);//파일저장
				System.out.println(serverFullName);
				productdto.setAttachedfile1(saveFileName);
				sqlSession.getMapper(mainImpl.class).productInsertAction(productdto);
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}

       return "redirect:productList.do";
    }
    
    @RequestMapping(value = "directInsertAction.do", method = RequestMethod.POST)
    public String directInsertAction(
    		productDTO productdto,MultipartHttpServletRequest req,
    		HttpServletRequest request) {  	
    	
   
    	String traderule ="직거래";
    	productdto.setTraderule(traderule);
    	String address = request.getParameter("address");
    	System.out.println(address);
    	productdto.setAddress(address);
   
     //서버의 물리적경로 얻어오기
		String path=
				req.getSession().getServletContext().getRealPath("/resources/Upload");
		
		//폼값과 파일명을 저장후 View로 전달하기 위한 맵 컬렉션
		Map returnObj = new HashMap();
		try {
			//업로드폼의 file속성의 필드를 가져온다.(여기서는 2개임)
			Iterator itr = req.getFileNames();
			
			MultipartFile mfile = null;
			String fileName = "";
			List resultList = new ArrayList();
			

			/*
			 물리적경로를 기반으로 File객체를 생성한 후 지정된 디렉토리가
			 있는지 확인한다. 만약 없다면 mkdirs()로 생성한다. 
			 */
			File directory = new File(path);
			if(!directory.isDirectory()) {
				directory.mkdirs();
				/*
				 mkdir() 한 번에 하나의 디렉토리만 생성.
				 mkdirs() 한 번에 여러 디렉토리를 생성.
*/
			}
			
			//업로드폼의 file필드 갯수만큼 반복
			while(itr.hasNext()) {
				//전송된 파일의 이름을 읽어온다.
				fileName=(String)itr.next();
				mfile = req.getFile(fileName);
				System.out.println("mfile="+mfile);
				
				//한글깨짐방지 처리후 전송된 파일명을 가져옴
				String originalName =
						new String(mfile.getOriginalFilename().getBytes(),"UTF-8");
				
				//서버로 전송된 파일이 없다면 while문의 처음으로 돌아간다.
				if("".equals(originalName)) {//originalName 이 빈값이라면
					continue; //반복문 처음으로 돌아감
				}
				
				//파일명에서 확장자를 가져옴.
				String ext = originalName.substring(originalName.lastIndexOf('.'));
				//UUID를 통해 생성된 문자열과 확장자를 합쳐서 파일명 완성
				
				String saveFileName = getUuid() + ext;
				
				
				//물리적 경로에 새롭게 생성된 파일명으로 파일저장
			
				File serverFullName =
						new File(path + File.separator + saveFileName);
				mfile.transferTo(serverFullName);//파일저장
				System.out.println(serverFullName);
				productdto.setAttachedfile1(saveFileName);
		
				sqlSession.getMapper(mainImpl.class).directInsertAction(productdto);
	
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
       
       
       return "redirect:directList.do";
    }
    
    //판매자 상품문의
    @RequestMapping("insert_qna.do")
    public String productQnA(HttpServletRequest request,QnADTO qnaDTO) {
    	String userId = request.getParameter("id");
    	String idx = request.getParameter("idx");
    	qnaDTO.setProductNum(idx);
    	qnaDTO.setUserid(userId);
    	sqlSession.getMapper(mainImpl.class).insertQnA(qnaDTO);
    	
    	return "redirect:productView.do?idx="+idx;
    }
    
    //상품문의내용 상세보기
    @RequestMapping("qnaDetailView.do")
    public String productQnAView(Model model,HttpServletRequest request, @RequestParam("idx") String idx) {
    	System.out.println(idx);
    	QnADTO detaildto = new QnADTO();
    	detaildto.setQnaNum(idx);
    	QnADTO dto = sqlSession.getMapper(mainImpl.class).qnaView(detaildto);
    	
    	
    	productDTO pDto = new productDTO();
    	String pidx = dto.getProductNum();
    	pDto = sqlSession.getMapper(mainImpl.class).getSellerId(pidx);
    	model.addAttribute("dto",dto);
    	model.addAttribute("sellerid",pDto.getId());
    	return "qnaDetailView";
    }
    //상품문의내용 답변달기
    @RequestMapping("reply.do")
    public String reply(HttpServletRequest req, Model model,
    		@RequestParam("idx") String idx,
    		@RequestParam("bgroup")String bgroup) {
    	
    	System.out.println(idx);
    	QnADTO detaildto = new QnADTO();
    	detaildto.setQnaNum(idx);
    	detaildto.setBgroup(Integer.parseInt(bgroup));
    	QnADTO dto = sqlSession.getMapper(mainImpl.class).qnaView(detaildto);
    	
    	dto.setQnaTitle("[RE]"+dto.getQnaTitle());
    	dto.setQnaCon("\n\r\n\r---[원본글]---\n\r"+dto.getQnaCon());
    	model.addAttribute("originNum",idx);
    	model.addAttribute("replyRow",dto);
    	return "reply";
    }
    //답변글 입력
    @RequestMapping("replyAction.do")
    @ResponseBody
    public Map<String,Object> replyAction(HttpServletRequest req, Model model) {
    	Map<String,Object> map = new HashMap<String,Object>();
    	QnADTO rpdto = new QnADTO();
    	
    	rpdto.setQnaTitle(req.getParameter("title"));
    	rpdto.setQnaCon(req.getParameter("contents"));
    	rpdto.setUserid(req.getParameter("userid"));
    	rpdto.setProductNum(req.getParameter("productNum"));
    	rpdto.setBgroup(Integer.parseInt(req.getParameter("bgroup")));
    	rpdto.setBstep(Integer.parseInt(req.getParameter("bstep")));
    	rpdto.setBindent(Integer.parseInt(req.getParameter("bindent")));
    	
    	sqlSession.getMapper(mainImpl.class).replyPrevUpdate(Integer.parseInt(req.getParameter("bgroup")),Integer.parseInt(req.getParameter("bstep")));
  
    	int result = sqlSession.getMapper(mainImpl.class).qnaReply(rpdto);
    	System.out.println("result"+result);
    	if(result<=0) {
    		map.put("statusCode", 0);
    	}
    	else {
    		map.put("statusCode", 1);
    	}
    	return map;
    	
	}
    @RequestMapping("editQnA.do")
    public String editQnA(QnADTO qnaDTO,HttpServletRequest req, Model model,
    					@RequestParam("idx")String idx,
    					@RequestParam("title")String title,
    					@RequestParam("contents")String contents) {
    	
    	String prdNum = req.getParameter("productNum");
    	
    	qnaDTO.setQnaNum(idx);
    	qnaDTO.setQnaTitle(title);
    	qnaDTO.setQnaCon(contents);
    	System.out.println(title+"<>"+contents);
    	model.addAttribute("origin",qnaDTO);
    	model.addAttribute("productNum",prdNum);
    	System.out.println(qnaDTO.getQnaNum());
    	return "editQnA";
    }
    @RequestMapping("editAciton.do")
    @ResponseBody
    public  Map<String,Object> editAciton(Model model, HttpServletRequest req) {
    	
    	
    	Map<String,Object> map = new HashMap<String,Object>();
    	String idx = req.getParameter("idx");
    	String title = req.getParameter("title");
    	String contents = req.getParameter("contents");
    	String prdNum = req.getParameter("productNum");
    	System.out.println(idx);
    	System.out.println(title+"<>"+contents);
    	int result = sqlSession.getMapper(mainImpl.class).qnaEdit(idx,title,contents);
    	if(result<=0) {
    		map.put("statusCode", 0);
    	}
    	else {
    		map.put("statusCode", 1);
    	}
    	return map;
    }
    @RequestMapping("deleteAction.do")
    @ResponseBody
    public Map<String,Object> editDelete(Model model, HttpServletRequest req, HttpSession session) 
    {
    	Map<String,Object> map = new HashMap<String,Object>();
    	String prdNum = req.getParameter("productNum");
    	
    	int result = sqlSession.getMapper(mainImpl.class).qnaDelete(req.getParameter("idx"));
    	if(result<=0) {
    		map.put("statusCode", 0);
    	}
    	else {
    		map.put("statusCode", 1);
    	}
    	return map;
    }
    @RequestMapping("charge2.do")
	public String charge(@RequestParam("sum") String sum,Model model,HttpServletRequest req) {

		
		HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		
		paydto.setId(id);
		paydto.setSum(sum);
		
		
		sqlSession.getMapper(mainImpl.class).charge(paydto);

			return "redirect:my.do";
	}
    
    @RequestMapping("cancelpay.do")
    public String cancelpay(@RequestParam("sum") String sum,@RequestParam("cidx") String cidx,
    		@RequestParam("ordernum") String ordernum,@RequestParam("sellerid") String sellerid,
    		HttpServletRequest req) {

    	HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
		String status = "결제취소";
		
		orderdetaildto.setCidx(cidx);
		orderdetaildto.setStatus(status);
		
		paydto.setId(id);
		paydto.setSum(sum);
		
    	sqlSession.getMapper(mainImpl.class).cancelpay(paydto);
    	sqlSession.getMapper(mainImpl.class).updatestatus(orderdetaildto);
    	
   
    	sqlSession.getMapper(mainImpl.class).subtractEmoney(sum,sellerid);
    	String emoney = sqlSession.getMapper(mainImpl.class).emoney(id);
		session.setAttribute("emoney1", emoney);
    	return "redirect:buylistdetail.do?ordernum="+ordernum;
    }
    @RequestMapping(value="reserve.do", produces = "text/html; charset=UTF-8")
    @ResponseBody
    public String reserve(HttpServletRequest req,HttpServletResponse response) {
    	
    	String result = "<script>alert('이미 신청했습니다'); history.back();</script>";
    	ReservationDTO reservationDTO = new ReservationDTO();
    	String id = req.getParameter("id");
    	String idx = req.getParameter("pidx");
    	String cnt = sqlSession.getMapper(mainImpl.class).checkReservation(id,idx);
    	
    	if(id=="") {
    		return "<script>alert('로그인 하세요'); location.href='login.do';</script>";
    	}
    	else if(cnt.equals("0")) {
	    	reservationDTO.setPidx(Integer.parseInt(req.getParameter("pidx")));
	    	reservationDTO.setId(id);
	    	try {
		    	sqlSession.getMapper(mainImpl.class).reserveInsert(reservationDTO);
		    	result = "<script>alert('신청 완료'); history.back();</script>";
	    	}
	    	catch(Exception e) {
	    		result = "<script>alert('신청 실패'); history.back();</script>";
	    	}
    	}
    	
    	return result;
    }
    @RequestMapping("reservationlist.do")
    public String reservationlist(HttpServletRequest req,Model model) {
    	System.out.println("dsadsa");
    	int idx = Integer.parseInt(req.getParameter("idx"));
    	if(req.getParameter("result").equals("예약완료")) {
    		model.addAttribute("result","yes");
    	}
    	ArrayList<ReservationDTO> rDTO = sqlSession.getMapper(mainImpl.class).reservationlist(idx);
    	model.addAttribute("rlist", rDTO);
    	model.addAttribute("idx", req.getParameter("idx"));
    	return "rlistModal";
    }
    @RequestMapping("completemodal.do")
    public String completemodal(HttpServletRequest req,  Model model) {
    	model.addAttribute("id", req.getParameter("id"));
    	model.addAttribute("idx", req.getParameter("idx"));
    	return "completeModal";
    }
    @RequestMapping("canclemodal.do")
    public String canclemodal(HttpServletRequest req,  Model model) {
    	model.addAttribute("id", req.getParameter("id"));
    	model.addAttribute("idx", req.getParameter("idx"));
    	return "cancleModal";
    }
    @RequestMapping("rcancle.do")
    public String rcancle(HttpServletRequest req,HttpServletResponse response,Model model) throws IOException {
    	String idx = req.getParameter("idx");
    	HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
    	productDTO pdto = new productDTO(); 
    	pdto.setIdx(idx);
    	try{
    		sqlSession.getMapper(mainImpl.class).cancleReservation(pdto);
    		sqlSession.getMapper(mainImpl.class).deleteReservation(idx,id);
    	}
    	catch(Exception e){
    		e.printStackTrace();
    		
    	}
    	
    	return "redirect:buylist.do";
    }
    @RequestMapping("rdelete.do")
    @ResponseBody
    public String rdelete(HttpServletRequest req,HttpServletResponse response,Model model) throws IOException {
    	String idx = req.getParameter("pidx");
    	HttpSession session = req.getSession();
		String id = (String) session.getAttribute("sec_id");
    	try{
    		sqlSession.getMapper(mainImpl.class).deleteReservation(idx,id);
    	}
    	catch(Exception e){
    		e.printStackTrace();
    		System.out.println("뭐가 안됐음");
    	}
    	return "<script>history.back();</script>";
    }
    @RequestMapping("rcomplete.do")
    public String rcomplete(HttpServletRequest req,HttpServletResponse response,Model model) throws IOException {
    	String id = req.getParameter("id");
    	String idx = req.getParameter("idx");
    	
    	if(id.equals("예약취소")) {
    		productDTO pdto = new productDTO(); 
        	pdto.setIdx(idx);
    		sqlSession.getMapper(mainImpl.class).cancleReservation(pdto);
    	}
    	else {
	    	productDTO pdto = new productDTO(); 
	    	pdto.setId(id);
	    	pdto.setIdx(idx);
	    	pdto.setResult(req.getParameter("result"));
	    	System.out.println(pdto.getId()+"/"+pdto.getIdx()+"/"+pdto.getResult());
	    	try{
	    		sqlSession.getMapper(mainImpl.class).updateProduct(pdto);
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		System.out.println("뭐가 안됐음");
	    	}
    	}
    	
    	return "redirect:sellList.do";
    }
    @RequestMapping("tcomplete.do")
    public void tcomplete(HttpServletRequest req,HttpServletResponse response,Model model) throws IOException {
    	String id = req.getParameter("id");
    	String idx = req.getParameter("idx");
    	
    	String result = sqlSession.getMapper(mainImpl.class).getproductresult(idx);
    	if(result.equals("예약완료")) {
	    	productDTO pdto = new productDTO(); 
	    	pdto.setId(id);
	    	pdto.setIdx(idx);
	    	pdto.setResult(req.getParameter("result"));
	    	try{
	    		sqlSession.getMapper(mainImpl.class).updateProduct(pdto);
	    	}catch(Exception e){
	    		e.printStackTrace();
	    		System.out.println("뭐가 안됐음");
	    	}
	    	response.sendRedirect("sellList.do");
    	}
    	else {
    		response.setContentType("text/html; charset=UTF-8");
    		PrintWriter out = response.getWriter();
    		out.println("<script>alert('예약상태를 확인하세요');location.href='sellList.do'</script>");
    		out.flush();
    	}
    }
}

















