package used;

public class cartDTO {

	private String cidx;
	private String id;
	private String sellerid;
	private String idx;
	private int price;
	private int buycount;
	private java.sql.Date adddate;
	
	
	public String getSellerid() {
		return sellerid;
	}
	public void setSellerid(String sellerid) {
		this.sellerid = sellerid;
	}
	public String getCidx() {
		return cidx;
	}
	public void setCidx(String cidx) {
		this.cidx = cidx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getBuycount() {
		return buycount;
	}
	public void setBuycount(int buycount) {
		this.buycount = buycount;
	}
	public java.sql.Date getAdddate() {
		return adddate;
	}
	public void setAdddate(java.sql.Date adddate) {
		this.adddate = adddate;
	}
	
	
	
	
}
