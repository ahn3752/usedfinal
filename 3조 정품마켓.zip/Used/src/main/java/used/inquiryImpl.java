package used;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

//Service 어노테이션이 있으면 스프링이 시작될 때 자동으로 빈이 생성!
//interface = 껍데기라고 생각하자!
@Service
public interface inquiryImpl 
{
	
	//ArrayList에 담는다
	public ArrayList<inquiryDTO> inquirylist(inquiryDTO inquirydto);
	
	//상세보기
	public inquiryDTO inquiryView(inquiryDTO inquirydto);
	
	//글쓰기
	public void inquiryWrite(inquiryDTO inquirydto);
	
}