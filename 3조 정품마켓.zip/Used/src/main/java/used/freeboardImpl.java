package used;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

//Service 어노테이션이 있으면 스프링이 시작될 때 자동으로 빈이 생성!
//interface = 껍데기라고 생각하자!
@Service
public interface freeboardImpl 
{
	//freeboardDTO를 ArrayList에 담는다! 
	public ArrayList<freeboardDTO> boardlist(freeboardDTO freeboarddto);
	
	//view는 idx값으로만 불러오기 때문에 배열을 사용하지 않는다!
	public freeboardDTO freeboardView(freeboardDTO freeboarddto);
	
	//글쓰기
	public void freeboardWrite(freeboardDTO freeboarddto);
	public void freeboardWriteNoFile(freeboardDTO freeboarddto);
	
	//수정하기
	//매퍼에 작성한 쿼리문 실행 freeboardModify를 impl, mapper id와 일치시켜야 한다.
	public void freeboardModify(freeboardDTO freeboarddto);
	
	//삭제하기
	public void freeboardDelete(String idx);
	
	//검색부분 , 페이징처리
	public int getTotalCount(freeboardDTO freeboarddto);
	public ArrayList<freeboardDTO> listPage(freeboardDTO freeboarddto);
	
	//조회수
	public int freeboardHits(freeboardDTO freeboarddto);
	
}