package used;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public interface auctionImpl {

	public ArrayList<auctionDTO> auctionlist(auctionDTO auctiondto);
	
	public auctionDTO auctionview(auctionDTO auctiondto);
	
	public String maxbid(String aidx);
	
	public void updatebprice(auctionDTO auctiondto);
	
	public void bid(bidDTO biddto);
	
	public ArrayList<bidDTO> bidlist(bidDTO biddto);
	
	public int bidcount(bidDTO biddto);
	
	public String selectsmsphone(String bidx);
	
	public void bidcountupdate(auctionDTO auctiondto);
	
	public void updateStatus(auctionDTO auctiondto);
	
	public void updateStatusbid(bidDTO biddto);
	
	public String maxbidx(String adix);
	
	public ArrayList<String> selectTime();
	
	public String selectmessagestatus(String aidx);
	
	public void updatemessagestatus(String aidx);
	
	public void updateStatussuccess(bidDTO biddto);
	
	public void insertSuccessBidder(successbidDTO successbiddto);
	
	public void auctionInsertAction(auctionDTO auctiondto);
	
	public ArrayList<auctionDTO> bidbreakdown(String mid);
	
	public void updatepay(String bprice, String aidx);
	
	public void directbuy(String aidx);
	
	public ArrayList<auctionDTO> mauctionlist(String lcategory, String mcategory); 
	
}
