package used;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;



@Transactional
@Service
public interface mainImpl {
	
	public productDTO productView(productDTO productdto);

	public ArrayList<productDTO> productlist(productDTO productdto);
	
	public ArrayList<productDTO> mproductlist(String lcategory, String mcategory); 
	
	public ArrayList<productDTO> mdirectlist(String lcategory, String mcategory); 

	//직거래 리스트
	public ArrayList<productDTO> directList(productDTO productdto);
	//현재위치 직거래 리스트
	public ArrayList<productDTO> directListNowAddr(productDTO productdto);
	//현재위치 물품리스트
	public ArrayList<productDTO> productlistNowAddr(productDTO productdto);
	
	//로그인한 id 전체 상품 등록 목록 출력
	public  ArrayList<productDTO> allproduct(String id);
	
	public void cart(cartDTO cartdto);

	public ArrayList<cartlistDTO> cartList(cartlistDTO cartlistdto);
	
	public void deletecart(cartDTO cartdto);

	public void cartupdate(cartDTO cartdto);

	public void orders(ordersDTO ordersdto) throws RuntimeException;

	public void orderdetail(orderdetailDTO orderdetaildto) throws RuntimeException;

	public void cartdelete(String id) throws RuntimeException;
	
	public void sellerreward(int sum,String id);
	
	public ArrayList<orderdetailDTO> sellerprice(String idx);
	
	
	public void pay(payDTO paydto);
	
	public void cancelpay(payDTO paydto);
	
	//emoney 출력
	public String emoney(String id);
	//emoney 충전
	public void charge(payDTO paydto);
	//emoney 차감
	public void subtractEmoney(String sum ,String id);
	
	public ArrayList<ordersDTO> orderlist(ordersDTO ordersdto);
	
	public String orderdetailidx(String ordernum);
	
	public String ordernum(String idx);
	
	public ArrayList<ordersDTO> buylist(ordersDTO ordersdto);
	
	public ArrayList<ordersDTO> buylistdetail(ordersDTO ordersdto);
	
	public ArrayList<ordersDTO> selllist(ordersDTO ordersdto);
	
	public ArrayList<auctionDTO> sellauction(String id);
	

	
	public void updatestatus(orderdetailDTO orderdetaildto);
	
	public int updatepcount(productDTO productdto);
	
	public ArrayList<String> checkcount();
	
	public void dropproduct(String id);
	
	public String cartcount(String id);
	
	public ArrayList<Integer> cartsum(String id);

	//상품등록
	public void productInsertAction(productDTO productdto);
	//직거래 장터 물품 등록
	public void directInsertAction(productDTO productdto);
	//상품수정
	public productDTO productModify(productDTO productdto);
	//수정처리
	public void productModifyAction(productDTO productdto);
	//삭제하기
	public void productDelete(String idx);
	
	

	public memberDTO find_by_Email(memberDTO memberdto);
	public memberDTO find_by_Id(memberDTO memberdto);
	
	//회원가입
	public void registration(memberDTO memberdto);
	
	public void regipay(String id);

	public int idchk(memberDTO memberdto);

	public int passchk(memberDTO memberdto);
	
	//SNS로그인 DB입력
	public Integer socialEmail(String id);
	
	public void socialInsert(memberDTO memberDTO);
	

	//상품문의 입력
	public void insertQnA(QnADTO qnaDTO);
	public ArrayList<QnADTO> qnaList(QnADTO qnaDTO);
	public QnADTO qnaView(QnADTO qnaDTO);
	public int qnaReply(QnADTO qnaDTO);
	public void replyPrevUpdate(final int strGroup,final int strStep);
	public productDTO getSellerId(String pidx);
	public int qnaDelete(String idx);
	//상품문의내역 레코드수 
	public int getTotalCount(QnADTO qnaDTO);
	public int qnaEdit(String qidx,String qtitle,String qcon);
	
	//Android
	public ArrayList<productDTO> aProductList(productDTO productdto);
	public productDTO aProductDetail(productDTO productdto);
	public memberDTO androidLogin(memberDTO memberdto);
	public int androidInsertMember(memberDTO memberdto);
	public Integer androidLapChk(memberDTO memberdto);
	
	//직거래관련
	
	public void reserveInsert(ReservationDTO reservationDTO);
	
	public String checkReservation(String id, String idx);
	
	public void cancleReservation(productDTO pDTO);
	
	public void deleteReservation(String idx,String id);
	
	public ArrayList<ReservationDTO> getReservation(String id);
	
	public ArrayList<ReservationDTO> reservationlist(int idx);
	
	public ArrayList<productDTO> dProductList(String id);


	public ArrayList<productDTO> dProductbuyList(String id);
	
	public void updateProduct(productDTO pDTO);
	
	public String getproductresult(String idx);
}
