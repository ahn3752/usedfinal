package used;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public interface myInfoImpl {
		
	public myInfoDTO myInfoview(myInfoDTO myInfoDTO);
	
	public void myInfomodifyaction(String id);	
	
}
