package used;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

//Service 어노테이션이 있으면 스프링이 시작될 때 자동으로 빈이 생성!
//interface = 껍데기라고 생각하자!
@Service
public interface reviewImpl 
{
	//reviewDTO를 ArrayList에 담는다! 
	public ArrayList<reviewDTO> reboardlist(reviewDTO reviewdto);
	
	//view는 idx값으로만 불러오기 때문에 배열을 사용하지 않는다!
	public reviewDTO reboardView(reviewDTO reviewdto);
	
	//글쓰기
	public void reboardWrite(reviewDTO reviewdto);
	public void reboardWriteNoFile(reviewDTO reviewdto);
	
	//수정하기
	//매퍼에 작성한 쿼리문 실행 freeboardModify를 impl, mapper id와 일치시켜야 한다.
	public void reboardModify(reviewDTO reviewdto);
	
	//삭제하기
	public void reboardDelete(String idx);
	
	//검색부분, 페이징처리
	public int getTotalCount(reviewDTO reviewdto);
	public ArrayList<reviewDTO> listPage(reviewDTO reviewdto);  
	
	//조회수
	public int reboardHits(reviewDTO reviewdto);
	
	//댓글
	public ArrayList<commentDTO> commentList(commentDTO commentdto);
	
	public void commentInsert(commentDTO commentdto);

	public void commentUpdate(commentDTO commentdto);
	
	public void commentDelete(commentDTO commentdto);
	
	
	
	
}

















