package used;

import java.util.ArrayList;

public class freeboardDTO 
{
	
	
	private String idx; 
	private String id;
	private String name;
	private String title;
	private String contents;
	private String flag;
	private String bgroup;
	private String bstep;
	private String bindent;
	private int hits;
	private String attachedfile;
	private java.sql.Date postdate;

	//02월09일 21시55분추가
	private int start;//select의 시작
	private int end;//끝	
	private String searchField;//검색할 필드명	
	private ArrayList<String> searchTxt;//검색어
	
	public String getSearchField() {
		return searchField;
	}
	public void setSearchField(String searchField) {
		this.searchField = searchField;
	}
	public ArrayList<String> getSearchTxt() {
		return searchTxt;
	}
	public void setSearchTxt(ArrayList<String> searchTxt) {
		this.searchTxt = searchTxt;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	/////
	//setter/getter 추가
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public java.sql.Date getPostdate() {
		return postdate;
	}
	public void setPostdate(java.sql.Date postdate) {
		this.postdate = postdate;
	}

	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getBgroup() {
		return bgroup;
	}
	public void setBgroup(String bgroup) {
		this.bgroup = bgroup;
	}
	public String getBstep() {
		return bstep;
	}
	public void setBstep(String bstep) {
		this.bstep = bstep;
	}
	public String getBindent() {
		return bindent;
	}
	public void setBindent(String bindent) {
		this.bindent = bindent;
	}
	public int getHits() {
		return hits;
	}
	public void setHits(int hits) {
		this.hits = hits;
	}
	public String getAttachedfile() {
		return attachedfile;
	}
	public void setAttachedfile(String attachedfile) {
		this.attachedfile = attachedfile;
	}
	
}
