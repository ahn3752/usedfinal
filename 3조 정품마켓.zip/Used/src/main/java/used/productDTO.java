package used;

import java.io.File;



public class productDTO {
	private String idx;
	private String pname;
	private String lcategory;
	private String mcategory;
	private String price;
	private String attachedfile1;
	private java.sql.Date postdate;
	private String traderule;
	private String result;
	private String contents;
	private String id;
	private int count;
	/* 직거래를 위한 주소 추가, 000시(도) 000구 000동까지만	 */
	private String address;
	private String reservation;
	//orderdetail idx조인
		private int pidx;
	public String getReservation() {
		return reservation;
	}
	public void setReservation(String reservation) {
		this.reservation = reservation;
	}
	
	
	public int getPidx() {
		return pidx;
	}
	public void setPidx(int pidx) {
		this.pidx = pidx;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getLcategory() {
		return lcategory;
	}
	public void setLcategory(String lcategory) {
		this.lcategory = lcategory;
	}
	public String getMcategory() {
		return mcategory;
	}
	public void setMcategory(String mcategory) {
		this.mcategory = mcategory;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getAttachedfile1() {
		return attachedfile1;
	}
	public void setAttachedfile1(String serverFullName) {
		this.attachedfile1 = serverFullName;
	}

	public java.sql.Date getPostdate() {
		return postdate;
	}
	public void setPostdate(java.sql.Date postdate) {
		this.postdate = postdate;
	}
	public String getTraderule() {
		return traderule;
	}
	public void setTraderule(String traderule) {
		this.traderule = traderule;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
	
}
