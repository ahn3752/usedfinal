package used;

public class aBoardDTO {

	
	private String idx;
	private String id;
	private String title;
	private String contents;
	private String flag;
	private String bgroup;
	private String bstep;
	private String bindent;
	private String hits;
	private String attachedfile;
	private java.sql.Date postdate;
	
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getBgroup() {
		return bgroup;
	}
	public void setBgroup(String bgroup) {
		this.bgroup = bgroup;
	}
	public String getBstep() {
		return bstep;
	}
	public void setBstep(String bstep) {
		this.bstep = bstep;
	}
	public String getBindent() {
		return bindent;
	}
	public void setBindent(String bindent) {
		this.bindent = bindent;
	}
	public String getHits() {
		return hits;
	}
	public void setHits(String hits) {
		this.hits = hits;
	}
	public String getAttachedfile() {
		return attachedfile;
	}
	public void setAttachedfile(String attachedfile) {
		this.attachedfile = attachedfile;
	}
	
	
	
	
}
