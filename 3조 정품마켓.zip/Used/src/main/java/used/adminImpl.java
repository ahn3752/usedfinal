package used;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public interface adminImpl {
	
	public ArrayList<adminDTO> memberlist(adminDTO adminDTO);
	
	public adminDTO view(adminDTO adminDTO);
	
	public void membermodify(adminDTO admindto);
	
	public int memberdelete(String id);
	
	public ArrayList<aBoardDTO> boardlist(aBoardDTO aboarddto);
	
	public aBoardDTO boardview(aBoardDTO aboarddto);
	
	public void aBoardmodify(aBoardDTO aboarddto);
	
	public int aBoarddelete(String idx);
	
	public void aBoardwrite(aBoardDTO aboarddto);
	
	public ArrayList<productDTO> aProductlist(String traderule);
	
	public productDTO aProductmodify(String idx);
	
	public void aProductmodifyaction(productDTO productdto);
	
	public void aProductdelete(String idx);
	
	public ArrayList<auctionDTO> aAuctionlist();
	
	public auctionDTO aAuctionmodify(auctionDTO auctiondto);
	
	public void aAuctionmodifyaction(auctionDTO auctiondto);
	
	public void aAuctiondelete(String aidx);
	
	
	
}
