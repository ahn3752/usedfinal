package used;

public class cartlistDTO {
	
	private String cidx;
	private String id;
	private String idx;
	private int count;
	private String sellerid;
	private java.sql.Date adddate;
	
	
	
	private int num;
	private String pname;
	private int price;
	private String attachedfile1;
	private int buycount;

	public String getSellerid() {
		return sellerid;
	}
	public void setSellerid(String sellerid) {
		this.sellerid = sellerid;
	}
	public int getBuycount() {
		return buycount;
	}
	public void setBuycount(int buycount) {
		this.buycount = buycount;
	}
	public String getCidx() {
		return cidx;
	}
	public void setCidx(String cidx) {
		this.cidx = cidx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public java.sql.Date getAdddate() {
		return adddate;
	}
	public void setAdddate(java.sql.Date adddate) {
		this.adddate = adddate;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getAttachedfile1() {
		return attachedfile1;
	}
	public void setAttachedfile1(String attachedfile1) {
		this.attachedfile1 = attachedfile1;
	}
	
	
}
