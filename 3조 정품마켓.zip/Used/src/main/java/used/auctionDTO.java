package used;

public class auctionDTO {

	private String aidx;
	private String mid;
	private String atitle;
	private String lcategory;
	private String mcategory;
	private String attachedfile1;
	private String attachedfile2;
	private String attachedfile3;
	private String sdate;
	private String edate;
	private String sprice;
	private String eprice;
	private String status;
	private String acontent;
	private int bidcount;
	//////////////////////
	//bid 조인
	private String bidx;
	private String bprice;
	private String bdate;
	private String bstatus;
	
	
	
	
	
	public String getAtitle() {
		return atitle;
	}
	public void setAtitle(String atitle) {
		this.atitle = atitle;
	}
	public String getAidx() {
		return aidx;
	}
	public void setAidx(String aidx) {
		this.aidx = aidx;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getLcategory() {
		return lcategory;
	}
	public void setLcategory(String lcategory) {
		this.lcategory = lcategory;
	}
	public String getMcategory() {
		return mcategory;
	}
	public void setMcategory(String mcategory) {
		this.mcategory = mcategory;
	}
	public String getAttachedfile1() {
		return attachedfile1;
	}
	public void setAttachedfile1(String attachedfile1) {
		this.attachedfile1 = attachedfile1;
	}
	public String getAttachedfile2() {
		return attachedfile2;
	}
	public void setAttachedfile2(String attachedfile2) {
		this.attachedfile2 = attachedfile2;
	}
	public String getAttachedfile3() {
		return attachedfile3;
	}
	public void setAttachedfile3(String attachedfile3) {
		this.attachedfile3 = attachedfile3;
	}

	public String getSprice() {
		return sprice;
	}
	public void setSprice(String sprice) {
		this.sprice = sprice;
	}
	public String getEprice() {
		return eprice;
	}
	public void setEprice(String eprice) {
		this.eprice = eprice;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAcontent() {
		return acontent;
	}
	public void setAcontent(String acontent) {
		this.acontent = acontent;
	}

	public String getBidx() {
		return bidx;
	}
	public void setBidx(String bidx) {
		this.bidx = bidx;
	}
	public String getBprice() {
		return bprice;
	}
	public void setBprice(String bprice) {
		this.bprice = bprice;
	}

	public String getBstatus() {
		return bstatus;
	}
	public void setBstatus(String bstatus) {
		this.bstatus = bstatus;
	}
	public int getBidcount() {
		return bidcount;
	}
	public void setBidcount(int bidcount) {
		this.bidcount = bidcount;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String sdate) {
		this.sdate = sdate;
	}
	public String getEdate() {
		return edate;
	}
	public void setEdate(String edate) {
		this.edate = edate;
	}
	public String getBdate() {
		return bdate;
	}
	public void setBdate(String bdate) {
		this.bdate = bdate;
	}
	
	
	
	
	
	
}
