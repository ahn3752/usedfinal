package used;

public class bidDTO {

	private String bidx;
	private String aidx;
	private String mid;
	private String bprice;
	private String bdate;
	private String bstatus;
	private String bidcount;
	
	
	
	public String getBidx() {
		return bidx;
	}
	public void setBidx(String bidx) {
		this.bidx = bidx;
	}
	public String getAidx() {
		return aidx;
	}
	public void setAidx(String aidx) {
		this.aidx = aidx;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getBprice() {
		return bprice;
	}
	public void setBprice(String bprice) {
		this.bprice = bprice;
	}
	public String getBdate() {
		return bdate;
	}
	public void setBdate(String bdate) {
		this.bdate = bdate;
	}
	public String getBstatus() {
		return bstatus;
	}
	public void setBstatus(String bstatus) {
		this.bstatus = bstatus;
	}
	public String getBidcount() {
		return bidcount;
	}
	public void setBidcount(String bidcount) {
		this.bidcount = bidcount;
	}
	
	
	
	
	
	
}
